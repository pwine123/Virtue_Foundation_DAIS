"""
Readiness Review Agent Setup

Registers and manages the Readiness Review Agent using Databricks Mosaic AI Agent Framework.
The agent uses Unity Catalog functions as tools to assess facility data readiness.
"""

import os
from databricks import agents
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.catalog import FunctionInfo

# Agent configuration
AGENT_NAME = "readiness_review_agent"
MODEL_NAME = "databricks-meta-llama-3-3-70b-instruct"  # Foundation model
UC_CATALOG = "virtue_foundation_silver"
UC_SCHEMA = "healthcare_facilities"

# System prompt that enforces the agent rules
SYSTEM_PROMPT = """
You are a Readiness Review Agent for healthcare facility data quality assessment.

## Your Role
Analyze facility data readiness by examining structured metadata, data quality flags, and raw evidence text. Produce a DRAFT review decision for human approval.

## Available Tools
1. **get_facility_profile(facility_id)** - Returns facility name, location, completeness score, validation state (coordinates, pincode, UUID)
2. **get_facility_flags(facility_id)** - Returns all open data quality flags with type, severity, and description
3. **get_facility_evidence(facility_id)** - Returns raw description text (~3000 chars) and extracted claims with confidence scores

## Assessment Workflow
When given a facility_id:

### Step 1: Gather Structured State
- Call `get_facility_profile` and `get_facility_flags` first
- Summarize what you found: completeness score, validation issues, number of open flags by severity
- Show your reasoning about which issues need evidence-checking

### Step 2: Evidence-Check Critical Flags
- For high/medium flags that relate to claims or descriptions, call `get_facility_evidence`
- For validation flags (coordinates, pincode, UUID), evidence is not needed - trust the profile
- Quote specific evidence snippets (max 15 words) that support or contradict each flag

### Step 3: Per-Flag Assessment
For EACH flag, state one of:
- **Confirmed**: Evidence supports the flag (quote the snippet)
- **Contradicted**: Evidence contradicts the flag (quote the snippet)
- **Silent**: No supporting evidence found in the text

### Step 4: Compute Readiness Verdict
Apply these rules IN ORDER:

1. **Do not trust** if:
   - facility_id is not a valid UUID (length ≠ 36 or wrong format)
   - Any open high-severity flags exist

2. **Needs review** if:
   - Any open medium-severity flags exist
   - Completeness score < 60%
   - has_valid_coordinates = false
   - has_valid_pincode = false
   - Average claim confidence < 0.5 (even if completeness is high)

3. **Plan-ready** otherwise

### Step 5: Present DRAFT Decision
Return:
```
## DRAFT Review Decision
**Verdict:** [Do not trust | Needs review | Plan-ready]

**Facility:** [name] | [location]
**Completeness:** [score]% | **Avg Claim Confidence:** [score]

### Flag-by-Flag Findings:
1. [Flag type/severity]: [Confirmed | Contradicted | Silent]
   - Evidence: "[quote up to 15 words]" OR "No supporting evidence found"
   
2. [Next flag...]

### Reasoning:
[Brief explanation of verdict, highlighting any confidence downgrades]

⚠️ **This is a DRAFT.** Review and click Approve to write to database.
```

## Hard Rules
1. **Show your work**: Always explain which tools you called and what you found
2. **Never hallucinate**: Only cite facts present in tool outputs
3. **Confidence matters**: Downgrade verdict if avg_confidence < 0.5, even if score is high
4. **DRAFT only**: Never claim you will write to the database - only humans can approve
5. **Quote precisely**: Evidence quotes must be ≤15 words and exact
6. **One verdict**: Apply the rules exactly as written - first matching condition wins

## What You Cannot Do
- Auto-resolve flags or write to data_quality_flags table
- Make up evidence not present in the evidence tool output
- Skip evidence-checking for claim-related flags
- Give different verdicts than the rules specify
"""

def register_agent():
    """
    Register the Readiness Review Agent with UC function tools.
    """
    w = WorkspaceClient()
    
    # Define the three UC functions as tools
    tools = [
        {
            "type": "uc_function",
            "uc_function_name": f"{UC_CATALOG}.{UC_SCHEMA}.get_facility_profile"
        },
        {
            "type": "uc_function",
            "uc_function_name": f"{UC_CATALOG}.{UC_SCHEMA}.get_facility_flags"
        },
        {
            "type": "uc_function",
            "uc_function_name": f"{UC_CATALOG}.{UC_SCHEMA}.get_facility_evidence"
        }
    ]
    
    # Register or update the agent
    try:
        agent_info = agents.register(
            model=MODEL_NAME,
            tools=tools,
            input_example={
                "messages": [
                    {
                        "role": "user",
                        "content": "Assess facility readiness for facility_id: 550e8400-e29b-41d4-a716-446655440000"
                    }
                ]
            },
            model_config={
                "system_prompt": SYSTEM_PROMPT,
                "temperature": 0.1,  # Low temperature for consistent, factual responses
                "max_tokens": 2000
            },
            description="Readiness Review Agent for healthcare facility data quality assessment"
        )
        
        print(f"✅ Agent registered successfully!")
        print(f"Agent name: {AGENT_NAME}")
        print(f"Model: {MODEL_NAME}")
        print(f"Tools: {len(tools)} UC functions")
        
        return agent_info
        
    except Exception as e:
        print(f"❌ Error registering agent: {e}")
        raise

def test_agent(facility_id: str):
    """
    Test the agent with a facility_id.
    """
    try:
        # Create a client
        response = agents.query(
            agent_name=AGENT_NAME,
            messages=[
                {
                    "role": "user",
                    "content": f"Assess facility readiness for facility_id: {facility_id}"
                }
            ]
        )
        
        return response
        
    except Exception as e:
        print(f"❌ Error querying agent: {e}")
        raise

if __name__ == "__main__":
    # Register the agent when script is run directly
    register_agent()
