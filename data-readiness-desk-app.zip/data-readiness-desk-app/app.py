import streamlit as st
import pandas as pd
import os

# Page config
st.set_page_config(
    page_title="Data Readiness Desk",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Main content
st.title("🏥 Healthcare Facility Data Readiness Desk")

st.success("✅ **App is running successfully!**")

st.markdown("""
Welcome to the Data Readiness Desk! This app helps you monitor, validate, and improve 
the quality of healthcare facility data before it powers other applications.

### 🎯 Features

**Navigate using the sidebar** to:
* 📊 **Dashboard** - View quality metrics and trends
* 🔍 **Issue Triage** - Prioritize and filter data issues  
* ✏️ **Data Cleaning** - Interactive facility editing
* 🗺️ **Geocoding** - Fix missing coordinates
* 📋 **Bulk Operations** - Batch updates and fixes
* 📈 **Progress Tracker** - Audit logs and statistics

### ⚙️ Configuration Needed

To enable full functionality, configure these environment variables in the App settings:

1. **DATABRICKS_SERVER_HOSTNAME**: `dbc-5f2b3389-e754.cloud.databricks.com`
2. **DATABRICKS_HTTP_PATH**: SQL Warehouse path (e.g., `/sql/1.0/warehouses/cd0b9c81a1e25c9d`)
3. **DATABRICKS_TOKEN**: Your personal access token

**How to configure:**
1. Go to the **Configuration** tab in this app
2. Add these environment variables
3. Redeploy the app

### 📚 Data Tables

The app works with these Unity Catalog tables:
* `virtue_foundation_silver.healthcare_facilities.facilities_clean`
* `virtue_foundation_silver.healthcare_facilities.data_quality_flags`
* `virtue_foundation_silver.healthcare_facilities.facility_specialties`
* `virtue_foundation_silver.healthcare_facilities.facility_equipment`

### 🔐 Permissions

Grant the app service principal (`app-51rw2v data-readiness-desk`) SELECT permissions on these tables.
""")

# Quick actions  
st.markdown("### 📍 Quick Start")

col1, col2, col3 = st.columns(3)

with col1:
    st.info("""
    **Step 1: Configure**
    
    Add environment variables in the app settings
    """)

with col2:
    st.info("""
    **Step 2: Grant Access**
    
    Give app service principal table permissions
    """)

with col3:
    st.info("""
    **Step 3: Explore**
    
    Navigate to pages using the sidebar
    """)

# Status check
with st.expander("🔍 Environment Status"):
    st.code(f"""
DATABRICKS_SERVER_HOSTNAME: {os.getenv('DATABRICKS_SERVER_HOSTNAME', '❌ Not set')}
DATABRICKS_HTTP_PATH: {os.getenv('DATABRICKS_HTTP_PATH', '❌ Not set')}
DATABRICKS_TOKEN: {'✅ Set' if os.getenv('DATABRICKS_TOKEN') else '❌ Not set'}
    """)
