"""
Data validation utilities for healthcare facility data
"""
import re
from typing import Optional, Tuple

# Geographic boundaries for India
INDIA_LAT_MIN = 6.0
INDIA_LAT_MAX = 38.0
INDIA_LON_MIN = 68.0
INDIA_LON_MAX = 98.0

def validate_coordinates(lat: float, lon: float) -> bool:
    """
    Validate that coordinates fall within India's geographic boundaries
    
    Args:
        lat: Latitude value
        lon: Longitude value
    
    Returns:
        True if coordinates are valid for India, False otherwise
    """
    if lat is None or lon is None:
        return False
    return (INDIA_LAT_MIN <= lat <= INDIA_LAT_MAX and 
            INDIA_LON_MIN <= lon <= INDIA_LON_MAX)

def validate_pincode(pincode: str) -> bool:
    """
    Validate Indian pincode format (6 digits)
    
    Args:
        pincode: Pincode string to validate
    
    Returns:
        True if pincode is valid, False otherwise
    """
    if not pincode:
        return False
    pincode_str = str(pincode).replace(' ', '').replace('-', '')
    return len(pincode_str) == 6 and pincode_str.isdigit()

def validate_phone(phone: str) -> bool:
    """
    Validate Indian phone number format
    
    Args:
        phone: Phone number string
    
    Returns:
        True if phone is valid, False otherwise
    """
    if not phone:
        return False
    # Remove common separators
    cleaned = re.sub(r'[\s\-\(\)]', '', str(phone))
    # Indian mobile: 10 digits, landline with STD: 10-11 digits
    return 10 <= len(cleaned) <= 11 and cleaned.isdigit()

def validate_email(email: str) -> bool:
    """
    Validate email format
    
    Args:
        email: Email string to validate
    
    Returns:
        True if email is valid, False otherwise
    """
    if not email:
        return False
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, str(email)) is not None

def parse_numeric(value: str) -> Optional[int]:
    """
    Extract first numeric value from a string
    
    Args:
        value: String that may contain numeric value
    
    Returns:
        Extracted integer or None
    """
    if not value:
        return None
    match = re.search(r'\d+', str(value))
    return int(match.group()) if match else None

def validate_capacity_range(value: int, min_val: int = 0, max_val: int = 10000) -> bool:
    """
    Validate that a capacity value (beds, doctors) is in reasonable range
    
    Args:
        value: Capacity value to validate
        min_val: Minimum acceptable value
        max_val: Maximum acceptable value
    
    Returns:
        True if value is in range, False otherwise
    """
    if value is None:
        return False
    return min_val <= value <= max_val

def clean_text_field(text: str) -> str:
    """
    Clean and normalize text fields
    
    Args:
        text: Text to clean
    
    Returns:
        Cleaned text
    """
    if not text:
        return ""
    # Remove extra whitespace
    cleaned = ' '.join(str(text).split())
    # Remove special characters at start/end
    cleaned = cleaned.strip('.,;:!?-_')
    return cleaned

def extract_state_name(address: str) -> Optional[str]:
    """
    Extract state name from address string
    
    Args:
        address: Full address string
    
    Returns:
        Extracted state name or None
    """
    if not address:
        return None
    
    # List of Indian states and UTs
    states = [
        'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
        'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka',
        'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram',
        'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu',
        'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal',
        'Andaman and Nicobar Islands', 'Chandigarh', 'Dadra and Nagar Haveli',
        'Daman and Diu', 'Delhi', 'Lakshadweep', 'Puducherry'
    ]
    
    address_upper = str(address).upper()
    for state in states:
        if state.upper() in address_upper:
            return state
    
    return None
