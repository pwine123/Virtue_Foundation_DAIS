"""
Data quality scoring and issue detection utilities
"""
from typing import Dict, List, Optional
from datetime import datetime
import pandas as pd

def calculate_completeness_score(facility_data: Dict) -> float:
    """
    Calculate completeness score based on presence of required fields
    
    Args:
        facility_data: Dictionary of facility fields
    
    Returns:
        Completeness score (0-100)
    """
    required_fields = [
        'name', 'address_city', 'address_state', 'address_pincode',
        'latitude', 'longitude', 'official_phone'
    ]
    
    important_fields = [
        'email', 'number_doctors', 'capacity_beds', 'district_name'
    ]
    
    # Required fields: 70% weight
    required_score = sum(1 for f in required_fields if facility_data.get(f)) / len(required_fields) * 70
    
    # Important fields: 30% weight
    important_score = sum(1 for f in important_fields if facility_data.get(f)) / len(important_fields) * 30
    
    return round(required_score + important_score, 1)

def calculate_accuracy_score(facility_data: Dict) -> float:
    """
    Calculate accuracy score based on data validity
    
    Args:
        facility_data: Dictionary of facility fields
    
    Returns:
        Accuracy score (0-100)
    """
    from utils.validators import validate_coordinates, validate_pincode, validate_phone
    
    checks = []
    
    # Check coordinates
    lat = facility_data.get('latitude')
    lon = facility_data.get('longitude')
    if lat and lon:
        checks.append(validate_coordinates(lat, lon))
    
    # Check pincode
    pincode = facility_data.get('address_pincode')
    if pincode:
        checks.append(validate_pincode(pincode))
    
    # Check phone
    phone = facility_data.get('official_phone')
    if phone:
        checks.append(validate_phone(phone))
    
    # Check capacity ranges
    doctors = facility_data.get('number_doctors')
    if doctors is not None:
        checks.append(0 <= doctors <= 10000)
    
    beds = facility_data.get('capacity_beds')
    if beds is not None:
        checks.append(0 <= beds <= 10000)
    
    if not checks:
        return 50.0  # No data to validate
    
    return round(sum(checks) / len(checks) * 100, 1)

def calculate_overall_quality_score(facility_data: Dict) -> float:
    """
    Calculate overall data quality score
    
    Args:
        facility_data: Dictionary of facility fields
    
    Returns:
        Overall quality score (0-100)
    """
    completeness = calculate_completeness_score(facility_data)
    accuracy = calculate_accuracy_score(facility_data)
    
    # Weight: 60% completeness, 40% accuracy
    return round(completeness * 0.6 + accuracy * 0.4, 1)

def detect_issues(facility_data: Dict, facility_id: str) -> List[Dict]:
    """
    Detect data quality issues for a facility
    
    Args:
        facility_data: Dictionary of facility fields
        facility_id: Facility identifier
    
    Returns:
        List of issue dictionaries
    """
    from utils.validators import validate_coordinates, validate_pincode, validate_phone
    
    issues = []
    
    # Missing critical fields
    if not facility_data.get('name'):
        issues.append({
            'facility_id': facility_id,
            'flag_type': 'missing_name',
            'flag_severity': 'critical',
            'flag_description': 'Facility name is missing',
            'flagged_at': datetime.now()
        })
    
    if not facility_data.get('latitude') or not facility_data.get('longitude'):
        issues.append({
            'facility_id': facility_id,
            'flag_type': 'missing_coordinates',
            'flag_severity': 'high',
            'flag_description': 'Geographic coordinates are missing',
            'flagged_at': datetime.now()
        })
    else:
        # Validate coordinates
        lat = facility_data.get('latitude')
        lon = facility_data.get('longitude')
        if not validate_coordinates(lat, lon):
            issues.append({
                'facility_id': facility_id,
                'flag_type': 'invalid_coordinates',
                'flag_severity': 'high',
                'flag_description': f'Coordinates ({lat}, {lon}) outside India boundaries',
                'flagged_at': datetime.now()
            })
    
    # Missing address components
    if not facility_data.get('address_city'):
        issues.append({
            'facility_id': facility_id,
            'flag_type': 'missing_address',
            'flag_severity': 'high',
            'flag_description': 'City is missing from address',
            'flagged_at': datetime.now()
        })
    
    if not facility_data.get('address_state'):
        issues.append({
            'facility_id': facility_id,
            'flag_type': 'missing_address',
            'flag_severity': 'high',
            'flag_description': 'State is missing from address',
            'flagged_at': datetime.now()
        })
    
    # Invalid pincode
    pincode = facility_data.get('address_pincode')
    if pincode and not validate_pincode(pincode):
        issues.append({
            'facility_id': facility_id,
            'flag_type': 'invalid_pincode',
            'flag_severity': 'medium',
            'flag_description': f'Invalid pincode format: {pincode}',
            'flagged_at': datetime.now()
        })
    
    # Missing contact information
    if not facility_data.get('official_phone'):
        issues.append({
            'facility_id': facility_id,
            'flag_type': 'missing_contact',
            'flag_severity': 'medium',
            'flag_description': 'Phone number is missing',
            'flagged_at': datetime.now()
        })
    
    # Missing capacity data
    if not facility_data.get('number_doctors') and not facility_data.get('capacity_beds'):
        issues.append({
            'facility_id': facility_id,
            'flag_type': 'missing_capacity_data',
            'flag_severity': 'low',
            'flag_description': 'Both doctor count and bed capacity are missing',
            'flagged_at': datetime.now()
        })
    
    return issues

def generate_quality_report(df: pd.DataFrame) -> Dict:
    """
    Generate summary quality report for a dataset
    
    Args:
        df: DataFrame of facility data
    
    Returns:
        Dictionary with quality metrics
    """
    total = len(df)
    
    report = {
        'total_facilities': total,
        'completeness': {
            'name': df['name'].notna().sum() / total * 100,
            'coordinates': (df['latitude'].notna() & df['longitude'].notna()).sum() / total * 100,
            'address': df['address_city'].notna().sum() / total * 100,
            'contact': df['official_phone'].notna().sum() / total * 100,
            'capacity': (df['number_doctors'].notna() | df['capacity_beds'].notna()).sum() / total * 100
        },
        'avg_quality_score': df['data_quality_score'].mean() if 'data_quality_score' in df.columns else 0,
        'production_ready': (df['data_quality_score'] >= 80).sum() if 'data_quality_score' in df.columns else 0
    }
    
    return report
