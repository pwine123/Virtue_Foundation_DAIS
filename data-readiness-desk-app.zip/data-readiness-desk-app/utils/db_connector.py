from databricks import sql
import os

def get_connection():
    """Get Databricks SQL connection using the app's attached SQL warehouse"""
    
    # Get server hostname from environment or use workspace default
    server_hostname = os.getenv("DATABRICKS_SERVER_HOSTNAME", "dbc-5f2b3389-e754.cloud.databricks.com")
    
    # Try to use the attached SQL warehouse
    # The app has a SQL warehouse resource attached (ID: c0e0eab321cc0487)
    http_path = os.getenv("DATABRICKS_HTTP_PATH", "/sql/1.0/warehouses/c0e0eab321cc0487")

    #/sql/1.0/warehouses/c0e0eab321cc0487
    
    # Use token-based auth with the app's internal token
    # Apps can access an internal token via specific environment variables
    access_token = os.getenv("DATABRICKS_TOKEN","dapi621321c976b61d591f97954d8ede2642")
    
    if not access_token:
        # App doesn't have token configured
        print("Database connection requires DATABRICKS_TOKEN environment variable")
        return None
    
    try:
        connection = sql.connect(
            server_hostname=server_hostname,
            http_path=http_path,
            access_token=access_token
        )
        return connection
    except Exception as e:
        print(f"Connection error: {str(e)}")
        return None
