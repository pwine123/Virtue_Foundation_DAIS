"""
Geocoding utilities for healthcare facilities
"""
from typing import Optional, Tuple
from math import radians, sin, cos, sqrt, atan2
import pandas as pd

def calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate distance between coordinates in km using Haversine formula"""
    R = 6371.0  # Earth radius in km
    
    lat1_rad = radians(lat1)
    lon1_rad = radians(lon1)
    lat2_rad = radians(lat2)
    lon2_rad = radians(lon2)
    
    dlat = lat2_rad - lat1_rad
    dlon = lon2_rad - lon1_rad
    
    a = sin(dlat / 2)**2 + cos(lat1_rad) * cos(lat2_rad) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    
    return round(R * c, 2)

def suggest_coordinates_from_pincode(pincode: str, pincode_df: pd.DataFrame) -> Optional[Tuple[float, float]]:
    """Get coordinates from pincode directory"""
    if not pincode or pincode_df is None or pincode_df.empty:
        return None
    
    pincode_clean = str(pincode).strip()
    matches = pincode_df[pincode_df['pincode'].astype(str) == pincode_clean]
    
    if not matches.empty and 'latitude' in matches.columns and 'longitude' in matches.columns:
        lat, lon = matches.iloc[0]['latitude'], matches.iloc[0]['longitude']
        if lat and lon and not (pd.isna(lat) or pd.isna(lon)):
            return (float(lat), float(lon))
    return None

def format_coordinates(lat: float, lon: float) -> str:
    """Format coordinates as human-readable string"""
    lat_dir = 'N' if lat >= 0 else 'S'
    lon_dir = 'E' if lon >= 0 else 'W'
    return f"{abs(lat):.4f}° {lat_dir}, {abs(lon):.4f}° {lon_dir}"
