"""
Pre-cache Agent Results for Demo

This script pre-computes agent assessments for 10-15 demo facilities and caches the results
to avoid model latency and rate limits during live demos.
"""

import pandas as pd
import json
from datetime import datetime
from databricks import agents
from databricks.sdk import WorkspaceClient
import time

# Agent configuration
AGENT_NAME = "readiness_review_agent"
UC_CATALOG = "virtue_foundation_silver"
UC_SCHEMA = "healthcare_facilities"

def get_demo_facilities(limit=15):
    """
    Get a diverse set of facilities for demo caching.
    """
    from databricks.sdk.service import sql as sql_service
    w = WorkspaceClient()
    
    query = f"""
    WITH facility_flag_counts AS (
        SELECT
            facility_id,
            COUNT(*) as open_flag_count,
            SUM(CASE WHEN flag_severity = 'high' THEN 1 ELSE 0 END) as high_count,
            SUM(CASE WHEN flag_severity = 'medium' THEN 1 ELSE 0 END) as medium_count,
            SUM(CASE WHEN flag_severity = 'low' THEN 1 ELSE 0 END) as low_count
        FROM {UC_CATALOG}.{UC_SCHEMA}.data_quality_flags
        WHERE resolved_at IS NULL
        GROUP BY facility_id
    ),
    
    verdict_mix AS (
        -- Get a mix of different verdict types
        SELECT
            f.facility_id,
            f.name,
            f.address_city,
            ae.validated_district,
            f.completeness_score,
            COALESCE(fc.open_flag_count, 0) as open_flags,
            COALESCE(fc.high_count, 0) as high_flags,
            COALESCE(fc.medium_count, 0) as medium_flags,
            COALESCE(fc.low_count, 0) as low_flags,
            CASE
                WHEN LENGTH(f.facility_id) != 36 OR f.facility_id NOT LIKE '%-%-%-%-%' THEN 'Do not trust'
                WHEN COALESCE(fc.high_count, 0) > 0 THEN 'Do not trust'
                WHEN COALESCE(fc.medium_count, 0) > 0 THEN 'Needs review'
                WHEN COALESCE(f.completeness_score, 0.0) < 60 THEN 'Needs review'
                ELSE 'Plan-ready'
            END as expected_verdict
        FROM {UC_CATALOG}.{UC_SCHEMA}.facilities_clean f
        LEFT JOIN {UC_CATALOG}.{UC_SCHEMA}.facility_address_enriched ae
            ON f.facility_id = ae.facility_id
        LEFT JOIN facility_flag_counts fc
            ON f.facility_id = fc.facility_id
        WHERE LENGTH(f.facility_id) = 36
            AND f.facility_id LIKE '%-%-%-%-%'
            AND COALESCE(fc.open_flag_count, 0) > 0
    )
    
    -- Get diverse sample: some with high flags, some with medium, various completeness
    (
        SELECT * FROM verdict_mix WHERE expected_verdict = 'Do not trust' LIMIT 3
    )
    UNION ALL
    (
        SELECT * FROM verdict_mix WHERE expected_verdict = 'Needs review' AND medium_flags > 0 LIMIT 5
    )
    UNION ALL
    (
        SELECT * FROM verdict_mix WHERE expected_verdict = 'Needs review' AND completeness_score < 60 LIMIT 4
    )
    UNION ALL
    (
        SELECT * FROM verdict_mix WHERE expected_verdict = 'Plan-ready' LIMIT 3
    )
    LIMIT {limit}
    """
    
    # Execute query
    statement = w.statement_execution.execute_statement(
        warehouse_id="your_warehouse_id",  # Replace with actual warehouse ID
        statement=query,
        catalog=UC_CATALOG,
        schema=UC_SCHEMA
    )
    
    # Convert to dataframe
    # Note: This is simplified - you'd need to properly parse the result
    return statement

def cache_agent_assessment(facility_id: str, facility_info: dict):
    """
    Run agent assessment and cache the result.
    """
    try:
        print(f"\nAssessing facility: {facility_info['name']} ({facility_id})...")
        
        # Query the agent
        response = agents.query(
            agent_name=AGENT_NAME,
            messages=[
                {
                    "role": "user",
                    "content": f"Assess facility readiness for facility_id: {facility_id}"
                }
            ]
        )
        
        # Build cache entry
        cache_entry = {
            "facility_id": facility_id,
            "facility_name": facility_info['name'],
            "cached_at": datetime.now().isoformat(),
            "agent_response": response,
            "facility_metadata": facility_info
        }
        
        print(f"  ✅ Cached successfully")
        return cache_entry
        
    except Exception as e:
        print(f"  ❌ Error: {str(e)}")
        return None

def main():
    """
    Main caching workflow.
    """
    print("📦 Starting agent result caching...")
    print(f"Agent: {AGENT_NAME}")
    print(f"Target: {UC_CATALOG}.{UC_SCHEMA}")
    print()
    
    # Get demo facilities
    print("Fetching demo facilities...")
    facilities_df = get_demo_facilities(limit=15)
    print(f"Found {len(facilities_df)} facilities to cache")
    print()
    
    # Cache each facility
    cache_results = []
    for idx, row in facilities_df.iterrows():
        facility_id = row['facility_id']
        facility_info = {
            'name': row['name'],
            'city': row.get('address_city', 'Unknown'),
            'district': row.get('validated_district', 'Unknown'),
            'completeness': row.get('completeness_score', 0),
            'high_flags': row.get('high_flags', 0),
            'medium_flags': row.get('medium_flags', 0),
            'expected_verdict': row.get('expected_verdict', 'Unknown')
        }
        
        cache_entry = cache_agent_assessment(facility_id, facility_info)
        if cache_entry:
            cache_results.append(cache_entry)
        
        # Rate limiting: wait between requests
        if idx < len(facilities_df) - 1:
            print("  Waiting 5s before next request...")
            time.sleep(5)
    
    # Save cache to file
    cache_file = "agent_cache.json"
    with open(cache_file, 'w') as f:
        json.dump(cache_results, f, indent=2, default=str)
    
    print()
    print(f"✅ Caching complete!")
    print(f"Cached {len(cache_results)} out of {len(facilities_df)} facilities")
    print(f"Cache saved to: {cache_file}")
    print()
    print("Summary:")
    verdict_counts = {}
    for entry in cache_results:
        verdict = entry['facility_metadata'].get('expected_verdict', 'Unknown')
        verdict_counts[verdict] = verdict_counts.get(verdict, 0) + 1
    
    for verdict, count in verdict_counts.items():
        print(f"  {verdict}: {count}")

if __name__ == "__main__":
    main()
