"""
Configuration file for Data Readiness Desk App
Contains database connections, catalog/schema names, and app settings
"""

import os
from dataclasses import dataclass
from typing import List, Dict

# ============================================================================
# DATABASE CONFIGURATION
# ============================================================================

@dataclass
class DatabaseConfig:
    """Databricks connection configuration"""
    
    # Databricks connection details
    server_hostname: str = "dbc-5f2b3389-e754.cloud.databricks.com"
    http_path: str = os.getenv("DATABRICKS_APP_URL", "")
    access_token: str = "dapi621321c976b61d591f97954d8ede2642"
    
    # Catalog and schema names
    bronze_catalog: str = "databricks_virtue_foundation_dataset_dais_2026"
    bronze_schema: str = "virtue_foundation_dataset"
    silver_catalog: str = "virtue_foundation_silver"
    silver_schema: str = "healthcare_facilities"
    
    # Table names
    facilities_table: str = "facilities_clean"
    specialties_table: str = "facility_specialties"
    equipment_table: str = "facility_equipment"
    procedures_table: str = "facility_procedures"
    capabilities_table: str = "facility_capabilities"
    quality_flags_table: str = "data_quality_flags"
    audit_log_table: str = "transformation_audit_log"
    address_enriched_table: str = "facility_address_enriched"
    district_health_table: str = "facility_district_health_context"
    
    def get_full_table_name(self, table_name: str, layer: str = "silver") -> str:
        """Get fully qualified table name"""
        if layer == "silver":
            return f"`{self.silver_catalog}`.`{self.silver_schema}`.`{table_name}`"
        elif layer == "bronze":
            return f"`{self.bronze_catalog}`.`{self.bronze_schema}`.`{table_name}`"
        else:
            raise ValueError(f"Unknown layer: {layer}")


# ============================================================================
# APP CONFIGURATION
# ============================================================================

@dataclass
class AppConfig:
    """Application settings and UI configuration"""
    
    # App metadata
    app_name: str = "Data Readiness Desk"
    app_version: str = "1.0.0"
    app_icon: str = "🏥"
    
    # Page configuration
    page_title: str = "Healthcare Facility Data Readiness"
    layout: str = "wide"
    initial_sidebar_state: str = "expanded"
    
    # Pagination
    default_page_size: int = 50
    max_page_size: int = 500
    
    # Data quality thresholds
    quality_score_excellent: float = 90.0
    quality_score_good: float = 70.0
    quality_score_fair: float = 50.0
    
    # Issue severity colors
    severity_colors: Dict[str, str] = None
    
    def __post_init__(self):
        if self.severity_colors is None:
            self.severity_colors = {
                'critical': '#FF3621',
                'high': '#FFAB00',
                'medium': '#00A972',
                'low': '#919191'
            }


# ============================================================================
# DATA VALIDATION RULES
# ============================================================================

@dataclass
class ValidationRules:
    """Data validation rules and constraints"""
    
    # Geographic boundaries for India
    india_lat_min: float = 6.0
    india_lat_max: float = 38.0
    india_lon_min: float = 68.0
    india_lon_max: float = 98.0
    
    # Pincode validation
    pincode_length: int = 6
    
    # Capacity constraints
    min_doctors: int = 0
    max_doctors: int = 10000
    min_beds: int = 0
    max_beds: int = 10000
    
    # Required fields for production readiness
    required_fields: List[str] = None
    
    def __post_init__(self):
        if self.required_fields is None:
            self.required_fields = [
                'name',
                'address_city',
                'address_state',
                'latitude',
                'longitude',
                'address_pincode',
                'official_phone'
            ]
    
    def validate_coordinates(self, lat: float, lon: float) -> bool:
        """Check if coordinates are within India boundaries"""
        return (self.india_lat_min <= lat <= self.india_lat_max and 
                self.india_lon_min <= lon <= self.india_lon_max)
    
    def validate_pincode(self, pincode: str) -> bool:
        """Validate Indian pincode format"""
        if not pincode:
            return False
        pincode_str = str(pincode).replace(' ', '')
        return len(pincode_str) == self.pincode_length and pincode_str.isdigit()


# ============================================================================
# ISSUE DEFINITIONS
# ============================================================================

@dataclass
class IssueDefinitions:
    """Definitions for data quality issue types"""
    
    issue_types: Dict[str, Dict[str, str]] = None
    
    def __post_init__(self):
        if self].issue_types is None:
            self.issue_types = {
                'missing_coordinates': {
                    'severity': 'high',
                    'description': 'Facility is missing geographic coordinates',
                    'fix_guidance': 'Use geocoding service or manually enter lat/lon'
                },
                'invalid_coordinates': {
                    'severity': 'high',
                    'description': 'Coordinates are outside India boundaries',
                    'fix_guidance': 'Verify address and re-geocode'
                },
                'missing_capacity_data': {
                    'severity': 'medium',
                    'description': 'Missing both doctor count and bed capacity',
                    'fix_guidance': 'Contact facility or research online'
                },
                'non_numeric_capacity': {
                    'severity': 'medium',
                    'description': 'Capacity fields contain non-numeric values',
                    'fix_guidance': 'Parse text to extract numeric values'
                },
                'non_numeric_doctors': {
                    'severity': 'medium',
                    'description': 'Doctor count contains non-numeric values',
                    'fix_guidance': 'Parse text to extract numeric values'
                },
                'stale_data': {
                    'severity': 'medium',
                    'description': 'Data has not been updated in over 1 year',
                    'fix_guidance': 'Verify facility is still operational'
                },
                'invalid_pincode': {
                    'severity': 'medium',
                    'description': 'Pincode not found in India Post directory',
                    'fix_guidance': 'Verify address and correct pincode'
                },
                'low_completeness': {
                    'severity': 'low',
                    'description': 'Facility record has low data completeness',
                    'fix_guidance': 'Fill in missing required fields'
                },
                'duplicate_record': {
                    'severity': 'critical',
                    'description': 'Duplicate facility record detected',
                    'fix_guidance': 'Merge or delete duplicate'
                }
            }
    
    def get_issue_info(self, issue_type: str) -> Dict[str, str]:
        """Get information about an issue type"""
        return self.issue_types.get(issue_type, {
            'severity': 'unknown',
            'description': 'Unknown issue type',
            'fix_guidance': 'Contact administrator'
        })


# ============================================================================
# USER ROLES & PERMISSIONS
# ============================================================================

@dataclass
class UserPermissions:
    """User roles and permissions configuration"""
    
    roles: Dict[str, List[str]] = None
    
    def __post_init__(self):
        if self].roles is None:
            self.roles = {
                'admin': [
                    'view_dashboard',
                    'view_issues',
                    'edit_data',
                    'bulk_operations',
                    'delete_records',
                    'manage_users'
                ],
                'data_steward': [
                    'view_dashboard',
                    'view_issues',
                    'edit_data',
                    'bulk_operations'
                ],
                'viewer': [
                    'view_dashboard',
                    'view_issues'
                ]
            }
    
    def has_permission(self, role: str, permission: str) -> bool:
        """Check if role has specific permission"""
        return permission in self.roles.get(role, [])


# ============================================================================
# GEOCODING CONFIGURATION
# ============================================================================

@dataclass
class GeocodingConfig:
    """Configuration for geocoding services"""
    
    # Geocoding service (options: 'nominatim', 'google', 'mapbox')
    service: str = "nominatim"
    
    # API keys (set via environment variables)
    google_api_key: str = os.getenv("GOOGLE_GEOCODING_API_KEY", "")
    mapbox_api_key: str = os.getenv("MAPBOX_API_KEY", "")
    
    # Rate limiting
    requests_per_second: float = 1.0
    
    # Nominatim settings
    nominatim_user_agent: str = "data_readiness_desk/1.0"
    nominatim_timeout: int = 10


# ============================================================================
# LOGGING CONFIGURATION
# ============================================================================

@dataclass
class LoggingConfig:
    """Logging configuration"""
    
    log_level: str = os.getenv("LOG_LEVEL", "INFO")
    log_format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    log_to_file: bool = False
    log_file_path: str = "/tmp/data_readiness_desk.log"


# ============================================================================
# INSTANTIATE CONFIGURATIONS
# ============================================================================

# Create singleton instances
db_config = DatabaseConfig()
app_config = AppConfig()
validation_rules = ValidationRules()
issue_definitions = IssueDefinitions()
user_permissions = UserPermissions()
geocoding_config = GeocodingConfig()
logging_config = LoggingConfig()


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_config_summary() -> Dict:
    """Get summary of all configurations for debugging"""
    return {
        'database': {
            'silver_catalog': db_config.silver_catalog,
            'silver_schema': db_config.silver_schema,
            'connection_configured': bool(db_config.server_hostname and db_config.access_token)
        },
        'app': {
            'name': app_config.app_name,
            'version': app_config.app_version
        },
        'validation': {
            'required_fields_count': len(validation_rules.required_fields),
            'india_boundaries': f"Lat: {validation_rules.india_lat_min}-{validation_rules.india_lat_max}, "
                               f"Lon: {validation_rules.india_lon_min}-{validation_rules.india_lon_max}"
        },
        'issues': {
            'defined_issue_types': len(issue_definitions.issue_types)
        }
    }


def validate_config() -> List[str]:
    """Validate configuration and return list of errors"""
    errors = []
    
    # Check database connection
    if not db_config.server_hostname:
        errors.append("DATABRICKS_SERVER_HOSTNAME not set")
    if not db_config.http_path:
        errors.append("DATABRICKS_HTTP_PATH not set")
    if not db_config.access_token:
        errors.append("DATABRICKS_TOKEN not set")
    
    # Check geocoding if enabled
    if geocoding_config.service == 'google' and not geocoding_config.google_api_key:
        errors.append("Google Geocoding API key not set")
    if geocoding_config.service == 'mapbox' and not geocoding_config.mapbox_api_key:
        errors.append("Mapbox API key not set")
    
    return errors


# ============================================================================
# EXPORT ALL
# ============================================================================

__all__ = [
    'db_config',
    'app_config',
    'validation_rules',
    'issue_definitions',
    'user_permissions',
    'geocoding_config',
    'logging_config',
    'get_config_summary',
    'validate_config'
]