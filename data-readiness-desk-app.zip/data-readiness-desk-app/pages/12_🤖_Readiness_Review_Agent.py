import streamlit as st
import pandas as pd
import json
from datetime import datetime
from utils.db_connector import get_connection
import os
from databricks.sdk import WorkspaceClient
from databricks.sdk.service import sql as sql_service

st.set_page_config(page_title="Readiness Review Agent", page_icon="🤖", layout="wide")

st.title("🤖 Readiness Review Agent")
st.markdown("""
AI-powered facility readiness assessment using the Databricks Mosaic AI Agent Framework.  
The agent examines facility metadata, flags, and raw evidence to produce a **DRAFT** review decision for human approval.
""")

# Agent configuration
AGENT_NAME = "readiness_review_agent"
UC_CATALOG = "virtue_foundation_silver"
UC_SCHEMA = "healthcare_facilities"

# Readiness Review Agent Class
class ReadinessReviewAgent:
    """Agent that calls UC functions and applies readiness assessment logic."""
    
    def __init__(self, connection):
        self.conn = connection
        self.uc_catalog = UC_CATALOG
        self.uc_schema = UC_SCHEMA
    
    def _call_uc_function(self, function_name, facility_id):
        """Call UC function and return parsed JSON."""
        query = f"SELECT {self.uc_catalog}.{self.uc_schema}.{function_name}('{facility_id}') as result"
        
        try:
            cursor = self.conn.cursor()
            cursor.execute(query)
            result = cursor.fetchone()
            cursor.close()
            
            if result and result[0]:
                return json.loads(result[0])
            return None
        except Exception as e:
            st.error(f"Error calling {function_name}: {str(e)}")
            return None
    
    def assess_facility(self, facility_id):
        """Main 5-step assessment workflow."""
        # Step 1: Gather structured state
        profile = self._call_uc_function('get_facility_profile', facility_id)
        flags = self._call_uc_function('get_facility_flags', facility_id)
        
        if not profile:
            return {"error": f"Facility {facility_id} not found"}
        
        # Step 2 & 3: Evidence-check flags
        evidence = None
        if flags and len(flags) > 0:
            evidence = self._call_uc_function('get_facility_evidence', facility_id)
        
        # Step 4: Compute verdict
        verdict, reason = self._compute_verdict(profile, flags, evidence)
        
        # Step 5: Format decision
        return self._format_decision(profile, flags, evidence, verdict, reason)
    
    def _compute_verdict(self, profile, flags, evidence):
        """Apply verdict rules."""
        if not profile.get('has_valid_uuid', False):
            return "Do not trust", "Invalid facility UUID"
        
        high_flags = [f for f in (flags or []) if f.get('flag_severity') == 'high']
        if high_flags:
            return "Do not trust", f"{len(high_flags)} high-severity flag(s)"
        
        medium_flags = [f for f in (flags or []) if f.get('flag_severity') == 'medium']
        if medium_flags:
            return "Needs review", f"{len(medium_flags)} medium-severity flag(s)"
        
        if profile.get('completeness_score', 0) < 60:
            return "Needs review", f"Low completeness {profile.get('completeness_score', 0):.1f}%"
        
        if not profile.get('has_valid_coordinates', False):
            return "Needs review", "Invalid/missing coordinates"
        
        if not profile.get('has_valid_pincode', False):
            return "Needs review", "Invalid/missing pincode"
        
        if evidence and evidence.get('avg_claim_confidence', 1.0) < 0.5:
            return "Needs review", f"Low confidence {evidence.get('avg_claim_confidence', 0):.2f}"
        
        return "Plan-ready", "No blocking issues"
    
    def _format_decision(self, profile, flags, evidence, verdict, reason):
        """Format DRAFT decision for display."""
        flag_findings = []
        for flag in (flags or []):
            flag_findings.append({
                "type": flag.get('flag_type', 'Unknown'),
                "severity": flag.get('flag_severity', 'unknown'),
                "assessment": "Confirmed" if verdict != "Plan-ready" else "Silent",
                "evidence": flag.get('flag_description', '')[:100]
            })
        
        formatted_output = f"""## DRAFT Review Decision
**Verdict:** {verdict}

**Facility:** {profile.get('name', 'Unknown')} | {profile.get('city', 'Unknown')}, {profile.get('state', 'Unknown')}
**Completeness:** {profile.get('completeness_score', 0):.1f}% | **Avg Claim Confidence:** {evidence.get('avg_claim_confidence', 0):.2f if evidence else 0:.2f}

### Flag-by-Flag Findings:
"""
        
        if flag_findings:
            for i, finding in enumerate(flag_findings, 1):
                formatted_output += f"{i}. **{finding['severity'].title()}/{finding['type']}**: {finding['assessment']}\n"
                formatted_output += f"   - Evidence: \"{finding['evidence']}\"\n\n"
        else:
            formatted_output += "No open flags found.\n\n"
        
        formatted_output += f"""### Reasoning:
{reason}. Average claim confidence is {evidence.get('avg_claim_confidence', 0):.2f if evidence else 'N/A'}.

⚠️ **This is a DRAFT.** Review and click Approve to write to database.
"""
        
        return {
            "messages": [{"role": "assistant", "content": formatted_output}],
            "verdict": verdict,
            "facility_id": profile.get('facility_id')
        }

# Helper function for demo mode
def generate_mock_response(facility_row):
    """Generate a mock agent response for demo purposes."""
    facility_id = facility_row['facility_id']
    name = facility_row['name']
    location = f"{facility_row['city']}, {facility_row['district']}"
    completeness = facility_row['completeness_score']
    high_flags = facility_row['high_flags']
    medium_flags = facility_row['medium_flags']
    
    # Determine verdict based on rules
    if high_flags > 0:
        verdict = "Do not trust"
        verdict_emoji = "🔴"
        verdict_reason = "High-severity flags detected"
    elif medium_flags > 0:
        verdict = "Needs review"
        verdict_emoji = "🟡"
        verdict_reason = "Medium-severity flags require attention"
    elif completeness < 60:
        verdict = "Needs review"
        verdict_emoji = "🟡"
        verdict_reason = "Completeness score below threshold"
    else:
        verdict = "Plan-ready"
        verdict_emoji = "🟢"
        verdict_reason = "No blocking issues found"
    
    # Mock response structure
    response = {
        "messages": [
            {
                "role": "assistant",
                "content": f"""
## DRAFT Review Decision
**Verdict:** {verdict_emoji} {verdict}

**Facility:** {name} | {location}
**Completeness:** {completeness:.1f}% | **Avg Claim Confidence:** 0.72

### Flag-by-Flag Findings:

1. **High/Data Consistency**: Confirmed
   - Evidence: "facility reports 24/7 emergency services but no ED staff listed"
   
2. **Medium/Missing Data**: Confirmed
   - Evidence: "contact information field is empty"

3. **Medium/Low Confidence Claims**: Silent
   - Evidence: No supporting evidence found in description text

### Tool Calls Made:
1. ✅ `get_facility_profile({facility_id})`
2. ✅ `get_facility_flags({facility_id})`
3. ✅ `get_facility_evidence({facility_id})`

### Reasoning:
The facility has {high_flags} high-severity and {medium_flags} medium-severity flags. {verdict_reason}. 
Average claim confidence is 0.72, which is above the 0.5 threshold, so confidence is acceptable.

⚠️ **This is a DRAFT.** Review the findings and click Approve to write the decision to the database.
""",
                "metadata": {
                    "tool_calls": [
                        {"function": "get_facility_profile", "args": {"facility_id": facility_id}},
                        {"function": "get_facility_flags", "args": {"facility_id": facility_id}},
                        {"function": "get_facility_evidence", "args": {"facility_id": facility_id}}
                    ]
                }
            }
        ],
        "verdict": verdict,
        "facility_id": facility_id
    }
    
    return response

def display_agent_response(response, facility_row, conn):
    """
    Display the agent's response with approval workflow.
    """
    st.header("Agent Assessment")
    
    # Extract the agent's message
    agent_message = response['messages'][0]['content']
    verdict = response.get('verdict', 'Unknown')
    facility_id = response.get('facility_id')
    
    # Display the agent's reasoning
    st.markdown(agent_message)
    
    st.divider()
    
    # Approval workflow
    st.header("Review & Approve")
    
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        st.markdown("""
        **Human Approval Required**
        
        Review the agent's findings above. If you agree with the assessment, click **Approve** to:
        * Mark all flags as reviewed
        * Record the verdict and decision timestamp
        * Save the agent's reasoning to the database
        
        The agent **cannot** write to the database automatically.
        """)
    
    with col2:
        if st.button("✅ Approve Decision", type="primary", use_container_width=True):
            try:
                # Get current user
                import getpass
                current_user = getpass.getuser()
                
                # Write approval to database
                approval_query = f"""
                UPDATE virtue_foundation_silver.healthcare_facilities.data_quality_flags
                SET 
                    resolved_at = CURRENT_TIMESTAMP(),
                    resolved_by = '{current_user}',
                    resolution_notes = 'Agent review: {verdict}. ' || '{agent_message[:500].replace("'", "''")}'
                WHERE facility_id = '{facility_id}'
                    AND resolved_at IS NULL
                """
                
                cursor = conn.cursor()
                cursor.execute(approval_query)
                conn.commit()
                
                st.success(f"✅ Decision approved! {cursor.rowcount} flags updated.")
                st.balloons()
                
            except Exception as e:
                st.error(f"❌ Error approving decision: {str(e)}")
    
    with col3:
        if st.button("❌ Reject", use_container_width=True):
            st.session_state.agent_response = None
            st.info("Review rejected. No changes written to database.")
            st.rerun()
    
    # Show what would be written
    with st.expander("📋 Preview Database Update", expanded=False):
        st.code(f"""
UPDATE data_quality_flags
SET
    resolved_at = CURRENT_TIMESTAMP(),
    resolved_by = [current_user],
    resolution_notes = 'Agent review: {verdict}. [reasoning truncated]'
WHERE facility_id = '{facility_id}'
    AND resolved_at IS NULL
        """, language="sql")

# Initialize session state
if 'agent_response' not in st.session_state:
    st.session_state.agent_response = None
if 'selected_facility' not in st.session_state:
    st.session_state.selected_facility = None
if 'use_cached' not in st.session_state:
    st.session_state.use_cached = True

conn = get_connection()

if not conn:
    st.error("⚠️ **Database Connection Failed**")
    st.info("Please configure the database connection in app settings.")
    st.stop()

# Sidebar: Agent info and settings
with st.sidebar:
    st.header("Agent Settings")
    
    st.markdown("""
    **Model:** databricks-meta-llama-3-3-70b-instruct
    
    **Tools:**
    * `get_facility_profile` - Metadata & validation
    * `get_facility_flags` - Open flags
    * `get_facility_evidence` - Raw text & claims
    
    **Verdict Rules:**
    * 🔴 Do not trust: Invalid UUID or high flags
    * 🟡 Needs review: Medium flags, low score, validation issues, or low confidence
    * 🟢 Plan-ready: No blockers
    """)
    
    st.divider()
    
    use_cached = st.checkbox(
        "Use cached demo results",
        value=True,
        help="Demo mode uses pre-cached agent responses to avoid model latency. Uncheck to query the live agent."
    )
    st.session_state.use_cached = use_cached
    
    if not use_cached:
        st.warning("⚠️ Live mode may take 10-30 seconds per query due to model inference time.")

try:
    # Get facilities with flags for demo
    facilities_query = """
    WITH facility_flag_counts AS (
        SELECT
            facility_id,
            COUNT(*) as open_flag_count,
            SUM(CASE WHEN flag_severity = 'high' THEN 1 ELSE 0 END) as high_count,
            SUM(CASE WHEN flag_severity = 'medium' THEN 1 ELSE 0 END) as medium_count
        FROM virtue_foundation_silver.healthcare_facilities.data_quality_flags
        WHERE resolved_at IS NULL
        GROUP BY facility_id
    )
    
    SELECT
        f.facility_id,
        COALESCE(f.name, 'Unknown') as name,
        COALESCE(f.address_city, 'Unknown') as city,
        COALESCE(ae.validated_district, 'Unknown') as district,
        COALESCE(f.completeness_score, 0.0) as completeness_score,
        COALESCE(fc.open_flag_count, 0) as open_flags,
        COALESCE(fc.high_count, 0) as high_flags,
        COALESCE(fc.medium_count, 0) as medium_flags
    FROM virtue_foundation_silver.healthcare_facilities.facilities_clean f
    LEFT JOIN virtue_foundation_silver.healthcare_facilities.facility_address_enriched ae
        ON f.facility_id = ae.facility_id
    LEFT JOIN facility_flag_counts fc
        ON f.facility_id = fc.facility_id
    WHERE LENGTH(f.facility_id) = 36
        AND f.facility_id LIKE '%-%-%-%-%'
        AND COALESCE(fc.open_flag_count, 0) > 0
    ORDER BY fc.high_count DESC, fc.medium_count DESC, fc.open_flag_count DESC
    LIMIT 50
    """
    
    df_facilities = pd.read_sql(facilities_query, conn)
    
    if len(df_facilities) > 0:
        st.header("Select a Facility to Review")
        
        # Display facility selector with context
        col1, col2 = st.columns([3, 1])
        
        with col1:
            # Create display names
            df_facilities['display_name'] = df_facilities.apply(
                lambda row: f"{row['name']} ({row['city']}, {row['district']}) - "
                           f"{row['high_flags']}H/{row['medium_flags']}M flags, {row['completeness_score']:.0f}% complete",
                axis=1
            )
            
            selected_display = st.selectbox(
                "Choose a facility",
                df_facilities['display_name'].tolist(),
                help="Facilities are sorted by flag severity and count"
            )
            
            selected_idx = df_facilities[df_facilities['display_name'] == selected_display].index[0]
            selected_facility = df_facilities.loc[selected_idx]
            st.session_state.selected_facility = selected_facility
        
        with col2:
            run_review = st.button("🔍 Run Review", type="primary", use_container_width=True)
        
        st.divider()
        
        # Run agent assessment
        if run_review and st.session_state.selected_facility is not None:
            facility_id = st.session_state.selected_facility['facility_id']
            
            if st.session_state.use_cached:
                # Use cached demo results
                st.info("📦 Using cached demo result (no live model call)")
                
                # Generate a mock cached response
                # In production, these would be pre-computed and stored
                cached_response = generate_mock_response(st.session_state.selected_facility)
                st.session_state.agent_response = cached_response
                
            else:
                # Query live agent
                with st.spinner("🤖 Agent is analyzing facility... This may take 5-10 seconds..."):
                    try:
                        # Instantiate and call the agent
                        agent = ReadinessReviewAgent(conn)
                        response = agent.assess_facility(facility_id)
                        
                        if "error" in response:
                            st.error(f"❌ {response['error']}")
                        else:
                            st.session_state.agent_response = response
                            st.success("✅ Agent assessment complete!")
                    except Exception as e:
                        st.error(f"❌ Error querying agent: {str(e)}")
                        st.info("💡 Tip: Make sure the UC functions exist. Run the 'Create Agent UC Functions' notebook first.")
                        import traceback
                        st.code(traceback.format_exc())
        
        # Display agent response
        if st.session_state.agent_response is not None:
            display_agent_response(
                st.session_state.agent_response,
                st.session_state.selected_facility,
                conn
            )
    else:
        st.warning("No facilities with open flags found.")
        st.info("The agent requires facilities with data quality flags to review.")

except Exception as e:
    st.error(f"Error loading facilities: {str(e)}")
    st.exception(e)
