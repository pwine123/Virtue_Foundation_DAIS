import streamlit as st
import pandas as pd
import uuid
from datetime import datetime
from utils.db_connector import get_connection

st.set_page_config(page_title="Facility Issue Triage", page_icon="🔍", layout="wide")

st.title("🔍 Facility Issue Triage")
st.markdown("""
View and manage data quality flags grouped by facility. Prioritized by severity and flag type.
Claim facilities to review and resolve issues.
""")

conn = get_connection()

if not conn:
    st.error("⚠️ **Database Connection Failed**")
    st.info("Please configure the DATABRICKS_TOKEN environment variable.")
    st.stop()

# Get current user for claim tracking
if 'reviewer_name' not in st.session_state:
    st.session_state.reviewer_name = "current_user"

# Tabs for valid vs corrupted records
tab1, tab2 = st.tabs(["📋 Valid Facilities", "⚠️ Corrupted Records"])

with tab2:
    st.header("⚠️ Corrupted Records (Invalid Facility IDs)")
    
    try:
        corrupted_query = """
        SELECT 
            f.facility_id,
            f.name,
            f.address_city,
            f.address_state,
            COUNT(DISTINCT q.flag_id) as flag_count
        FROM virtue_foundation_silver.healthcare_facilities.facilities_clean f
        INNER JOIN virtue_foundation_silver.healthcare_facilities.data_quality_flags q
            ON f.facility_id = q.facility_id
        WHERE q.resolved_at IS NULL
            AND (
                LENGTH(f.facility_id) != 36
                OR f.facility_id NOT LIKE '%-%-%-%-%'
                OR f.facility_id IS NULL
            )
        GROUP BY f.facility_id, f.name, f.address_city, f.address_state
        ORDER BY flag_count DESC
        LIMIT 100
        """
        
        corrupted_df = pd.read_sql(corrupted_query, conn)
        
        if not corrupted_df.empty:
            st.warning(f"⚠️ Found {len(corrupted_df)} facilities with invalid UUID format")
            
            st.dataframe(
                corrupted_df,
                use_container_width=True,
                column_config={
                    "facility_id": "Facility ID (Invalid)",
                    "name": "Facility Name",
                    "address_city": "City",
                    "address_state": "State",
                    "flag_count": st.column_config.NumberColumn("Open Flags", format="%d 🚩")
                }
            )
            
            st.info("""
            **Next Steps:**
            * These records have malformed facility_id values (not valid UUIDs)
            * They need to be corrected in the source data or assigned new valid UUIDs
            * Contact data engineering team to investigate source system issues
            """)
        else:
            st.success("✅ No corrupted facility records found!")
    
    except Exception as e:
        st.error(f"Error loading corrupted records: {str(e)}")
        import traceback
        st.code(traceback.format_exc())

with tab1:
    st.header("📋 Open Issues by Facility")
    
    try:
        # Get filter options
        filter_col1, filter_col2, filter_col3 = st.columns(3)
        
        with filter_col1:
            # Get available flag types
            flag_type_query = """
            SELECT DISTINCT flag_type
            FROM virtue_foundation_silver.healthcare_facilities.data_quality_flags
            WHERE resolved_at IS NULL
            ORDER BY flag_type
            """
            flag_types_df = pd.read_sql(flag_type_query, conn)
            flag_type_options = ['All'] + flag_types_df['flag_type'].tolist()
            selected_flag_type = st.selectbox("Flag Type", flag_type_options)
        
        with filter_col2:
            severity_options = ['All', 'high', 'medium', 'low']
            selected_severity = st.selectbox("Severity", severity_options)
        
        with filter_col3:
            sort_by_need = st.checkbox(
                "Sort by Health Need",
                value=False,
                help="Prioritize districts with higher health need (stunted, underweight, anaemic indicators)"
            )
        
        # Build main query with filters
        where_clauses = [
            "q.resolved_at IS NULL",
            "LENGTH(f.facility_id) = 36",
            "f.facility_id LIKE '%-%-%-%-%'"
        ]
        
        if selected_flag_type != 'All':
            selected_flag_type_safe = selected_flag_type.replace("'", "''")
            where_clauses.append(f"q.flag_type = '{selected_flag_type_safe}'")
        
        if selected_severity != 'All':
            where_clauses.append(f"q.flag_severity = '{selected_severity}'")
        
        where_clause = " AND ".join(where_clauses)
        
        # Main triage query with optional health need sorting
        if sort_by_need:
            triage_query = f"""
            WITH facility_flags AS (
                SELECT
                    f.facility_id,
                    f.name,
                    f.address_city,
                    f.address_state,
                    ae.validated_district,
                    f.address_pincode,
                    q.flag_id,
                    q.flag_type,
                    q.flag_severity,
                    q.flag_description,
                    q.flagged_at,
                    q.resolved_by
                FROM virtue_foundation_silver.healthcare_facilities.facilities_clean f
                INNER JOIN virtue_foundation_silver.healthcare_facilities.data_quality_flags q
                    ON f.facility_id = q.facility_id
                LEFT JOIN virtue_foundation_silver.healthcare_facilities.facility_address_enriched ae
                    ON f.facility_id = ae.facility_id
                WHERE {where_clause}
            ),
            
            facility_summary AS (
                SELECT
                    facility_id,
                    FIRST(name) as name,
                    FIRST(address_city) as address_city,
                    FIRST(address_state) as address_state,
                    FIRST(validated_district) as validated_district,
                    FIRST(address_pincode) as address_pincode,
                    COUNT(DISTINCT flag_id) as total_flags,
                    SUM(CASE WHEN flag_severity = 'high' THEN 1 ELSE 0 END) as high_count,
                    SUM(CASE WHEN flag_severity = 'medium' THEN 1 ELSE 0 END) as medium_count,
                    SUM(CASE WHEN flag_severity = 'low' THEN 1 ELSE 0 END) as low_count,
                    MAX(CASE WHEN flag_severity = 'high' THEN 1 
                             WHEN flag_severity = 'medium' THEN 2 
                             ELSE 3 END) as max_severity_rank,
                    COLLECT_SET(flag_type) as flag_types,
                    MAX(flagged_at) as latest_flag_date,
                    MAX(resolved_by) as claimed_by
                FROM facility_flags
                GROUP BY facility_id
            ),
            
            district_health_need AS (
                SELECT
                    district_name,
                    -- Clean and parse health indicators
                    CAST(REGEXP_REPLACE(REGEXP_REPLACE(REGEXP_REPLACE(
                        child_u5_who_are_stunted_height_for_age_18_pct, 
                        '[*\\s]', ''), '\\(([0-9.]+)\\)', '$1'), '[^0-9.]', '') AS DOUBLE) as stunted,
                    CAST(REGEXP_REPLACE(REGEXP_REPLACE(REGEXP_REPLACE(
                        child_u5_who_are_underweight_weight_for_age_18_pct, 
                        '[*\\s]', ''), '\\(([0-9.]+)\\)', '$1'), '[^0-9.]', '') AS DOUBLE) as underweight,
                    non_pregnant_w15_49_who_are_anaemic_lt_12_0_g_dl_22_pct as anaemic
                FROM virtue_foundation_silver.healthcare_facilities.facility_district_health_context
                GROUP BY district_name, child_u5_who_are_stunted_height_for_age_18_pct, 
                         child_u5_who_are_underweight_weight_for_age_18_pct, 
                         non_pregnant_w15_49_who_are_anaemic_lt_12_0_g_dl_22_pct
            )
            
            SELECT
                fs.facility_id,
                fs.name,
                fs.address_city,
                fs.address_state,
                fs.validated_district,
                fs.address_pincode,
                fs.total_flags,
                fs.high_count,
                fs.medium_count,
                fs.low_count,
                fs.flag_types,
                fs.latest_flag_date,
                fs.claimed_by,
                -- Compute district health need score
                COALESCE((dh.stunted + dh.underweight + dh.anaemic) / 3, 0) as district_need_score
            FROM facility_summary fs
            LEFT JOIN district_health_need dh
                ON UPPER(fs.validated_district) = UPPER(dh.district_name)
            ORDER BY 
                district_need_score DESC,
                max_severity_rank ASC,
                total_flags DESC
            LIMIT 100
            """
        else:
            triage_query = f"""
            WITH facility_flags AS (
                SELECT
                    f.facility_id,
                    f.name,
                    f.address_city,
                    f.address_state,
                    ae.validated_district,
                    f.address_pincode,
                    q.flag_id,
                    q.flag_type,
                    q.flag_severity,
                    q.flag_description,
                    q.flagged_at,
                    q.resolved_by
                FROM virtue_foundation_silver.healthcare_facilities.facilities_clean f
                INNER JOIN virtue_foundation_silver.healthcare_facilities.data_quality_flags q
                    ON f.facility_id = q.facility_id
                LEFT JOIN virtue_foundation_silver.healthcare_facilities.facility_address_enriched ae
                    ON f.facility_id = ae.facility_id
                WHERE {where_clause}
            ),
            
            facility_summary AS (
                SELECT
                    facility_id,
                    FIRST(name) as name,
                    FIRST(address_city) as address_city,
                    FIRST(address_state) as address_state,
                    FIRST(validated_district) as validated_district,
                    FIRST(address_pincode) as address_pincode,
                    COUNT(DISTINCT flag_id) as total_flags,
                    SUM(CASE WHEN flag_severity = 'high' THEN 1 ELSE 0 END) as high_count,
                    SUM(CASE WHEN flag_severity = 'medium' THEN 1 ELSE 0 END) as medium_count,
                    SUM(CASE WHEN flag_severity = 'low' THEN 1 ELSE 0 END) as low_count,
                    MAX(CASE WHEN flag_severity = 'high' THEN 1 
                             WHEN flag_severity = 'medium' THEN 2 
                             ELSE 3 END) as max_severity_rank,
                    COLLECT_SET(flag_type) as flag_types,
                    MAX(flagged_at) as latest_flag_date,
                    MAX(resolved_by) as claimed_by
                FROM facility_flags
                GROUP BY facility_id
            )
            
            SELECT
                facility_id,
                name,
                address_city,
                address_state,
                validated_district,
                address_pincode,
                total_flags,
                high_count,
                medium_count,
                low_count,
                flag_types,
                latest_flag_date,
                claimed_by
            FROM facility_summary
            ORDER BY 
                max_severity_rank ASC,
                total_flags DESC,
                latest_flag_date DESC
            LIMIT 100
            """
        
        facilities_df = pd.read_sql(triage_query, conn)
        
        if facilities_df.empty:
            st.success("🎉 No open issues matching your filters!")
            st.info("Try adjusting filters or check the 'Corrupted Records' tab.")
            st.stop()
        
        # Summary metrics
        st.markdown("---")
        metric_col1, metric_col2, metric_col3, metric_col4 = st.columns(4)
        
        with metric_col1:
            st.metric("Facilities with Issues", len(facilities_df))
        
        with metric_col2:
            total_flags = facilities_df['total_flags'].sum()
            st.metric("Total Open Flags", int(total_flags))
        
        with metric_col3:
            high_flags = facilities_df['high_count'].sum()
            st.metric("🔴 High Severity", int(high_flags))
        
        with metric_col4:
            claimed = len(facilities_df[facilities_df['claimed_by'].notna()])
            st.metric("📌 Claimed", claimed)
        
        # Info banner when sorting by need
        if sort_by_need:
            st.info("""
            🏥 **Sorting by Health Need**  
            Facilities are prioritized by their district's health need score (composite of NFHS-5 indicators: stunted children, underweight children, and anaemic women).  
            **Why?** Fix data quality in districts with the greatest health challenges first.
            """)
        
        st.markdown("---")
        
        # Display facilities
        for idx, facility in facilities_df.iterrows():
            with st.container():
                # Severity badge color
                if facility['high_count'] > 0:
                    severity_badge = "🔴 HIGH"
                    badge_color = "#dc3545"
                elif facility['medium_count'] > 0:
                    severity_badge = "🟡 MEDIUM"
                    badge_color = "#ffc107"
                else:
                    severity_badge = "🟢 LOW"
                    badge_color = "#28a745"
                
                # Header row
                col1, col2, col3, col4 = st.columns([3, 1, 1, 1])
                
                with col1:
                    st.subheader(f"🏥 {facility['name']}")
                    location_parts = []
                    if pd.notna(facility['address_city']):
                        location_parts.append(facility['address_city'])
                    if pd.notna(facility['validated_district']):
                        location_parts.append(f"{facility['validated_district']} District")
                    if pd.notna(facility['address_state']):
                        location_parts.append(facility['address_state'])
                    if pd.notna(facility['address_pincode']):
                        location_parts.append(str(facility['address_pincode']))
                    
                    location = ", ".join(location_parts) if location_parts else "Location not specified"
                    st.caption(f"📍 {location}")
                
                with col2:
                    st.markdown(f"""
                    <div style="text-align: center; padding: 8px; background-color: {badge_color}; color: white; border-radius: 6px; font-size: 14px; font-weight: bold;">
                        {severity_badge}
                    </div>
                    """, unsafe_allow_html=True)
                
                with col3:
                    st.metric("Open Flags", int(facility['total_flags']))
                
                with col4:
                    # Show claimed status
                    if pd.notna(facility['claimed_by']):
                        st.info(f"📌 Claimed by\n{facility['claimed_by']}")
                
                # Severity breakdown
                severity_col1, severity_col2, severity_col3 = st.columns(3)
                
                with severity_col1:
                    if facility['high_count'] > 0:
                        st.markdown(f"🔴 **High:** {int(facility['high_count'])}")
                
                with severity_col2:
                    if facility['medium_count'] > 0:
                        st.markdown(f"🟡 **Medium:** {int(facility['medium_count'])}")
                
                with severity_col3:
                    if facility['low_count'] > 0:
                        st.markdown(f"🟢 **Low:** {int(facility['low_count'])}")
                
                # Flag types
                flag_types = facility['flag_types']
                if flag_types is not None and (isinstance(flag_types, list) and len(flag_types) > 0 or isinstance(flag_types, str)):
                    # Parse the array string if needed
                    if isinstance(flag_types, str):
                        flag_types = eval(flag_types) if flag_types.startswith('[') else [flag_types]
                    if isinstance(flag_types, list) and len(flag_types) > 0:
                        st.caption(f"**Issue Types:** {', '.join(flag_types)}")
                
                # Action buttons
                action_col1, action_col2 = st.columns([1, 4])
                
                facility_id = str(facility['facility_id'])
                
                with action_col1:
                    # Claim button
                    if pd.isna(facility['claimed_by']):
                        if st.button("📌 Claim", key=f"claim_{facility_id}", use_container_width=True):
                            try:
                                # Update all flags for this facility to set resolved_by
                                update_sql = f"""
                                UPDATE virtue_foundation_silver.healthcare_facilities.data_quality_flags
                                SET resolved_by = '{st.session_state.reviewer_name}'
                                WHERE facility_id = '{facility_id.replace("'", "''")}'
                                    AND resolved_at IS NULL
                                """
                                
                                cursor = conn.cursor()
                                cursor.execute(update_sql)
                                cursor.close()
                                
                                st.success(f"✅ Claimed facility for review!")
                                st.info("Refresh the page to see updated status")
                            except Exception as e:
                                st.error(f"Error claiming facility: {str(e)}")
                    else:
                        st.caption(f"Claimed by\n{facility['claimed_by']}")
                
                with action_col2:
                    # View details button (placeholder)
                    if st.button("🔍 View Flag Details", key=f"view_{facility_id}"):
                        # Query detailed flags for this facility
                        detail_query = f"""
                        SELECT
                            flag_id,
                            flag_type,
                            flag_severity,
                            flag_description,
                            flagged_at,
                            resolved_by
                        FROM virtue_foundation_silver.healthcare_facilities.data_quality_flags
                        WHERE facility_id = '{facility_id.replace("'", "''")}'
                            AND resolved_at IS NULL
                        ORDER BY 
                            CASE flag_severity 
                                WHEN 'high' THEN 1 
                                WHEN 'medium' THEN 2 
                                ELSE 3 
                            END,
                            flag_type
                        """
                        
                        details_df = pd.read_sql(detail_query, conn)
                        
                        if not details_df.empty:
                            st.dataframe(
                                details_df,
                                use_container_width=True,
                                column_config={
                                    "flag_id": "Flag ID",
                                    "flag_type": "Type",
                                    "flag_severity": st.column_config.TextColumn(
                                        "Severity",
                                        help="Issue severity level"
                                    ),
                                    "flag_description": "Description",
                                    "flagged_at": st.column_config.DatetimeColumn(
                                        "Detected",
                                        format="YYYY-MM-DD HH:mm"
                                    ),
                                    "resolved_by": "Claimed By"
                                }
                            )
                
                st.markdown("---")
        
    except Exception as e:
        st.error(f"Error loading triage queue: {str(e)}")
        import traceback
        st.code(traceback.format_exc())

conn.close()
