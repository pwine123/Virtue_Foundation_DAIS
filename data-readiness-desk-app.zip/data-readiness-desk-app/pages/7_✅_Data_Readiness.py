import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from databricks import sql
import os
import re
from utils.db_connector import get_connection

st.set_page_config(page_title="Data Readiness", page_icon="✅", layout="wide")

st.title("✅ Data Readiness")

conn = get_connection()

# Database connection
#st.cache_resource

if not conn:
    st.error("⚠️ **Database Connection Failed**")
    st.info("Please configure the DATABRICKS_TOKEN environment variable.")
    st.stop()

try:
    # Data Trust Header
    st.header("🔒 Data Trust Metrics")
    
    # Query for all metrics
    trust_query = """
    SELECT 
        COUNT(*) as total_facilities,
        SUM(CASE 
            WHEN facility_id IS NULL OR facility_id = '' 
            OR LENGTH(REGEXP_REPLACE(facility_id, '[^-]', '')) != 4 
            OR LENGTH(facility_id) != 36
            THEN 1 ELSE 0 
        END) as corrupted_ids,
        SUM(CASE 
            WHEN latitude IS NOT NULL 
            AND longitude IS NOT NULL 
            AND latitude BETWEEN 6 AND 38 
            AND longitude BETWEEN 68 AND 98 
            THEN 1 ELSE 0 
        END) as valid_coords,
        SUM(CASE 
            WHEN address_pincode IS NOT NULL 
            AND LENGTH(CAST(address_pincode AS STRING)) = 6 
            THEN 1 ELSE 0 
        END) as valid_pincode
    FROM virtue_foundation_silver.healthcare_facilities.facilities_clean
    """
    
    trust_df = pd.read_sql(trust_query, conn)
    total = trust_df['total_facilities'][0]
    corrupted = trust_df['corrupted_ids'][0]
    valid_coords = trust_df['valid_coords'][0]
    valid_pincode = trust_df['valid_pincode'][0]
    
    # Display metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if st.button(f"**{total:,}**\n\nTotal Facilities", use_container_width=True):
            st.session_state.filter_type = 'all'
            st.rerun()
        st.caption("📊 All Records")
    
    with col2:
        pct_corrupted = (corrupted / total * 100) if total > 0 else 0
        color = "🔴" if pct_corrupted > 5 else "🟢"
        if st.button(f"{color} **{pct_corrupted:.1f}%**\n\nCorrupted IDs", use_container_width=True):
            st.session_state.filter_type = 'corrupted_ids'
            st.rerun()
        st.caption(f"{corrupted:,} records")
    
    with col3:
        pct_valid_coords = (valid_coords / total * 100) if total > 0 else 0
        color = "🟢" if pct_valid_coords > 80 else "🟡" if pct_valid_coords > 60 else "🔴"
        if st.button(f"{color} **{pct_valid_coords:.1f}%**\n\nValid Coordinates", use_container_width=True):
            st.session_state.filter_type = 'valid_coords'
            st.rerun()
        st.caption(f"{valid_coords:,} records")
    
    with col4:
        pct_valid_pincode = (valid_pincode / total * 100) if total > 0 else 0
        color = "🟢" if pct_valid_pincode > 80 else "🟡" if pct_valid_pincode > 60 else "🔴"
        if st.button(f"{color} **{pct_valid_pincode:.1f}%**\n\nValid Pincode", use_container_width=True):
            st.session_state.filter_type = 'valid_pincode'
            st.rerun()
        st.caption(f"{valid_pincode:,} records")
    
    st.markdown("---")
    
    # Completeness Score Histogram
    st.subheader("📈 Completeness Score Distribution")
    
    score_query = """
    SELECT data_quality_score as score
    FROM virtue_foundation_silver.healthcare_facilities.facilities_clean
    WHERE data_quality_score IS NOT NULL
    """
    score_df = pd.read_sql(score_query, conn)
    
    if not score_df.empty:
        col1, col2 = st.columns([3, 1])
        
        with col1:
            fig = px.histogram(score_df, x='score', nbins=20,
                             labels={'score': 'Completeness Score', 'count': 'Number of Facilities'},
                             color_discrete_sequence=['#1f77b4'])
            fig.update_layout(
                xaxis_title="Completeness Score",
                yaxis_title="Count",
                bargap=0.1
            )
            # Add vertical lines for thresholds
            fig.add_vline(x=60, line_dash="dash", line_color="red", annotation_text="Critical (60)")
            fig.add_vline(x=80, line_dash="dash", line_color="orange", annotation_text="Good (80)")
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            st.metric("Avg Score", f"{score_df['score'].mean():.1f}")
            st.metric("Median Score", f"{score_df['score'].median():.1f}")
            st.metric("Min Score", f"{score_df['score'].min():.1f}")
            st.metric("Max Score", f"{score_df['score'].max():.1f}")
    
    st.markdown("---")
    
    # Field Coverage Bar Chart
    st.subheader("📊 Field Coverage Analysis")
    
    coverage_query = """
    SELECT 
        ROUND(AVG(CASE WHEN description IS NOT NULL AND description != '' THEN 100 ELSE 0 END), 1) as description,
        ROUND(AVG(CASE WHEN email IS NOT NULL AND email != '' THEN 100 ELSE 0 END), 1) as email,
        ROUND(AVG(CASE WHEN official_phone IS NOT NULL AND official_phone != '' THEN 100 ELSE 0 END), 1) as official_phone,
        ROUND(AVG(CASE WHEN official_website IS NOT NULL AND official_website != '' THEN 100 ELSE 0 END), 1) as official_website,
        ROUND(AVG(CASE WHEN year_established IS NOT NULL THEN 100 ELSE 0 END), 1) as year_established,
        ROUND(AVG(CASE WHEN capacity_beds IS NOT NULL THEN 100 ELSE 0 END), 1) as capacity
    FROM virtue_foundation_silver.healthcare_facilities.facilities_clean
    """
    
    coverage_df = pd.read_sql(coverage_query, conn)
    
    # Reshape data for plotting
    coverage_data = pd.DataFrame({
        'Field': ['Description', 'Email', 'Phone', 'Website', 'Year Est.', 'Capacity'],
        'Coverage': [
            coverage_df['description'][0],
            coverage_df['email'][0],
            coverage_df['official_phone'][0],
            coverage_df['official_website'][0],
            coverage_df['year_established'][0],
            coverage_df['capacity'][0]
        ]
    })
    
    # Assign colors based on threshold
    coverage_data['Color'] = coverage_data['Coverage'].apply(
        lambda x: '#d62728' if x < 60 else '#2ca02c'  # Red if < 60%, green otherwise
    )
    
    fig = go.Figure()
    
    for idx, row in coverage_data.iterrows():
        fig.add_trace(go.Bar(
            x=[row['Coverage']],
            y=[row['Field']],
            orientation='h',
            marker_color=row['Color'],
            text=f"{row['Coverage']:.1f}%",
            textposition='outside',
            name=row['Field'],
            showlegend=False,
            hovertemplate=f"<b>{row['Field']}</b><br>Coverage: {row['Coverage']:.1f}%<extra></extra>"
        ))
    
    fig.update_layout(
        xaxis_title="Coverage %",
        xaxis_range=[0, 105],
        yaxis_title="",
        height=400,
        margin=dict(l=150)
    )
    
    # Add threshold line
    fig.add_vline(x=60, line_dash="dash", line_color="red", 
                  annotation_text="60% Threshold", annotation_position="top")
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Legend
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("🟢 **Green:** ≥ 60% coverage (acceptable)")
    with col2:
        st.markdown("🔴 **Red:** < 60% coverage (needs attention)")
    
    st.markdown("---")
    
    # Filtered Records Display
    if 'filter_type' in st.session_state:
        st.subheader("🔍 Filtered Records")
        
        if st.session_state.filter_type == 'all':
            records_query = """
            SELECT facility_id, name, address_city, address_state, data_quality_score
            FROM virtue_foundation_silver.healthcare_facilities.facilities_clean
            LIMIT 1000
            """
            st.info("Showing all facilities (limited to 1000 records)")
            
        elif st.session_state.filter_type == 'corrupted_ids':
            records_query = """
            SELECT facility_id, name, address_city, address_state, data_quality_score
            FROM virtue_foundation_silver.healthcare_facilities.facilities_clean
            WHERE facility_id IS NULL OR facility_id = '' 
               OR LENGTH(REGEXP_REPLACE(facility_id, '[^-]', '')) != 4 
               OR LENGTH(facility_id) != 36
            LIMIT 1000
            """
            st.warning(f"Showing facilities with corrupted/invalid facility IDs")
            
        elif st.session_state.filter_type == 'valid_coords':
            records_query = """
            SELECT facility_id, name, address_city, address_state, latitude, longitude, data_quality_score
            FROM virtue_foundation_silver.healthcare_facilities.facilities_clean
            WHERE latitude IS NOT NULL 
              AND longitude IS NOT NULL 
              AND latitude BETWEEN 6 AND 38 
              AND longitude BETWEEN 68 AND 98
            LIMIT 1000
            """
            st.success(f"Showing facilities with valid coordinates")
            
        elif st.session_state.filter_type == 'valid_pincode':
            records_query = """
            SELECT facility_id, name, address_city, address_state, address_pincode, data_quality_score
            FROM virtue_foundation_silver.healthcare_facilities.facilities_clean
            WHERE address_pincode IS NOT NULL 
              AND LENGTH(CAST(address_pincode AS STRING)) = 6
            LIMIT 1000
            """
            st.success(f"Showing facilities with valid pincodes")
        
        records_df = pd.read_sql(records_query, conn)
        
        st.dataframe(
            records_df,
            use_container_width=True,
            height=400
        )
        
        st.caption(f"Showing {len(records_df):,} records")
        
        if st.button("Clear Filter"):
            del st.session_state.filter_type
            st.rerun()
    
    conn.close()

except Exception as e:
    st.error(f"Error loading data: {str(e)}")
    import traceback
    st.code(traceback.format_exc())
