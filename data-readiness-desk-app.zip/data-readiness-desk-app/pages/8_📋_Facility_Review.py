import streamlit as st
import pandas as pd
import uuid
from datetime import datetime
from utils.db_connector import get_connection

st.set_page_config(page_title="Facility Review Queue", page_icon="📋", layout="wide")

conn = get_connection()

if not conn:
    st.error("⚠️ **Database Connection Failed**")
    st.info("Please configure the DATABRICKS_TOKEN environment variable.")
    st.stop()

# Create review_decisions table if needed
try:
    create_table_sql = """
    CREATE TABLE IF NOT EXISTS virtue_foundation_silver.healthcare_facilities.review_decisions (
        review_id STRING NOT NULL,
        facility_id STRING NOT NULL,
        reviewer STRING NOT NULL,
        decision STRING NOT NULL,
        field_reviewed STRING,
        note STRING,
        created_at TIMESTAMP NOT NULL
    )
    USING DELTA
    COMMENT 'Tracks facility review decisions and notes from the review queue'
    """
    cursor = conn.cursor()
    cursor.execute(create_table_sql)
    cursor.close()
except Exception as e:
    st.warning(f"Note: Could not create review_decisions table: {str(e)}")

# Get current user
if 'reviewer_name' not in st.session_state:
    st.session_state.reviewer_name = "current_user"

# Tabs
tab1, tab2 = st.tabs(["🔍 Review Queue", "📝 My Reviews"])

with tab2:
    st.header("📝 My Reviews")
    
    try:
        my_reviews_query = f"""
        SELECT 
            r.created_at,
            f.name as facility_name,
            r.decision,
            r.field_reviewed,
            r.note,
            f.address_city,
            f.address_state
        FROM virtue_foundation_silver.healthcare_facilities.review_decisions r
        LEFT JOIN virtue_foundation_silver.healthcare_facilities.facilities_clean f
            ON r.facility_id = f.facility_id
        WHERE r.reviewer = '{st.session_state.reviewer_name}'
        ORDER BY r.created_at DESC
        LIMIT 100
        """
        
        my_reviews_df = pd.read_sql(my_reviews_query, conn)
        
        if not my_reviews_df.empty:
            st.success(f"✅ You have reviewed {len(my_reviews_df)} facilities")
            
            # Group by decision type
            decision_counts = my_reviews_df['decision'].value_counts()
            col1, col2, col3 = st.columns(3)
            
            with col1:
                verified_count = decision_counts.get('verified', 0)
                st.metric("✅ Verified", verified_count)
            
            with col2:
                rejected_count = decision_counts.get('rejected', 0)
                st.metric("🚫 Rejected", rejected_count)
            
            with col3:
                needs_info_count = decision_counts.get('needs_more_info', 0)
                st.metric("ℹ️ Needs Info", needs_info_count)
            
            st.markdown("---")
            
            # Display reviews table
            display_df = my_reviews_df.copy()
            display_df['created_at'] = pd.to_datetime(display_df['created_at']).dt.strftime('%Y-%m-%d %H:%M')
            display_df['location'] = display_df.apply(
                lambda x: f"{x['address_city']}, {x['address_state']}" if pd.notna(x['address_city']) else 'N/A',
                axis=1
            )
            
            st.dataframe(
                display_df[['created_at', 'facility_name', 'decision', 'field_reviewed', 'note', 'location']],
                use_container_width=True,
                column_config={
                    "created_at": "Reviewed At",
                    "facility_name": "Facility",
                    "decision": "Decision",
                    "field_reviewed": "Field",
                    "note": "Note",
                    "location": "Location"
                }
            )
        else:
            st.info("You haven't reviewed any facilities yet. Go to the Review Queue tab to start!")
    
    except Exception as e:
        st.error(f"Error loading reviews: {str(e)}")

with tab1:
    st.title("🔍 Facility Review Queue")
    
    try:
        flagged_query = """
        SELECT
            f.facility_id,
            f.name,
            f.address_city,
            f.address_state,
            f.address_pincode,
            f.data_quality_score as completeness_score,
            COUNT(DISTINCT q.flag_id) as flag_count
        FROM virtue_foundation_silver.healthcare_facilities.facilities_clean f
        INNER JOIN virtue_foundation_silver.healthcare_facilities.data_quality_flags q
            ON f.facility_id = q.facility_id
        WHERE q.resolved_at IS NULL
            AND LENGTH(f.facility_id) = 36
            AND f.facility_id LIKE '%-%-%-%-%'
            AND f.name IS NOT NULL
            AND TRIM(f.name) != ''
            AND LENGTH(TRIM(f.name)) > 3
            AND f.name NOT LIKE '%bedded%'
            AND f.name NOT LIKE '%MBBS%'
            AND f.name NOT LIKE '%completed%'
            AND f.name NOT LIKE '%located in%'
        GROUP BY f.facility_id, f.name, f.address_city, f.address_state, f.address_pincode, f.data_quality_score
        ORDER BY flag_count DESC, f.data_quality_score ASC
        LIMIT 50
        """
        
        facilities_df = pd.read_sql(flagged_query, conn)
        
        if facilities_df.empty:
            st.success("🎉 No facilities in review queue!")
            st.info("All facilities have been reviewed or have no open data quality flags.")
            st.stop()
        
        st.info(f"📊 **{len(facilities_df)} facilities** in review queue")
        
        # Sidebar filter
        with st.sidebar:
            st.header("Filters")
            min_score = st.slider("Min Completeness Score", 0.0, 100.0, 0.0, 5.0)
            filtered_df = facilities_df[facilities_df['completeness_score'] >= min_score]
            st.metric("Filtered Facilities", len(filtered_df))
        
        # Display facilities
        for idx, facility in filtered_df.iterrows():
            with st.container():
                st.markdown("---")
                
                # Facility header
                col1, col2, col3 = st.columns([3, 1, 1])
                
                with col1:
                    st.subheader(f"🏥 {facility['name']}")
                    location_parts = [
                        facility['address_city'],
                        facility['address_state'],
                        facility['address_pincode']
                    ]
                    location = ", ".join([str(p) for p in location_parts if pd.notna(p)])
                    st.caption(f"📍 {location if location else 'Location not specified'}")
                
                with col2:
                    score = facility['completeness_score']
                    score_color = "🟢" if score >= 80 else "🟡" if score >= 60 else "🔴"
                    st.metric("Completeness", f"{score_color} {score:.1f}%")
                
                with col3:
                    st.metric("Open Flags", facility['flag_count'])
                
                # Get claims for this facility
                facility_id = str(facility['facility_id']).strip()
                
                # Validate facility_id
                if not facility_id or len(facility_id) != 36:
                    st.warning(f"⚠️ Invalid facility_id for {facility['name']}")
                    continue
                
                # Escape for SQL
                facility_id_escaped = facility_id.replace("'", "''")
                
                # Query all claim types
                claims_query = f"""
                SELECT 
                    'Capability' as claim_type,
                    capability_description as claim_text,
                    capability_category as category,
                    confidence_score,
                    source_text
                FROM virtue_foundation_silver.healthcare_facilities.facility_capabilities
                WHERE facility_id = '{facility_id_escaped}'
                
                UNION ALL
                
                SELECT 
                    'Equipment' as claim_type,
                    equipment_name as claim_text,
                    equipment_category as category,
                    confidence_score,
                    source_text
                FROM virtue_foundation_silver.healthcare_facilities.facility_equipment
                WHERE facility_id = '{facility_id_escaped}'
                
                UNION ALL
                
                SELECT 
                    'Procedure' as claim_type,
                    procedure_name as claim_text,
                    procedure_category as category,
                    confidence_score,
                    source_text
                FROM virtue_foundation_silver.healthcare_facilities.facility_procedures
                WHERE facility_id = '{facility_id_escaped}'
                
                UNION ALL
                
                SELECT 
                    'Specialty' as claim_type,
                    specialty_name as claim_text,
                    specialty_code as category,
                    confidence_score,
                    source_text
                FROM virtue_foundation_silver.healthcare_facilities.facility_specialties
                WHERE facility_id = '{facility_id_escaped}'
                
                ORDER BY confidence_score DESC
                """
                
                claims_df = pd.read_sql(claims_query, conn)
                
                if not claims_df.empty:
                    st.markdown("### 📝 Extracted Claims")
                    
                    # Group by claim type
                    for claim_type in ['Capability', 'Equipment', 'Procedure', 'Specialty']:
                        type_claims = claims_df[claims_df['claim_type'] == claim_type]
                        
                        if not type_claims.empty:
                            with st.expander(f"**{claim_type}s** ({len(type_claims)})", expanded=True):
                                # Display claims as cards
                                for claim_idx, claim in type_claims.iterrows():
                                    confidence = claim['confidence_score']
                                    
                                    # Confidence badge
                                    if pd.isna(confidence):
                                        badge = "⚪ Unknown"
                                        badge_color = "gray"
                                    elif confidence >= 0.8:
                                        badge = "🟢 High"
                                        badge_color = "green"
                                    elif confidence >= 0.5:
                                        badge = "🟡 Medium"
                                        badge_color = "orange"
                                    else:
                                        badge = "🔴 Low"
                                        badge_color = "red"
                                    
                                    # Claim card
                                    st.markdown(f"""
                                    <div style="border: 1px solid #ddd; border-radius: 8px; padding: 12px; margin-bottom: 10px; background-color: #f9f9f9;">
                                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                                            <strong>{claim['claim_text']}</strong>
                                            <span style="background-color: {badge_color}; color: white; padding: 2px 8px; border-radius: 4px; font-size: 11px;">{badge}</span>
                                        </div>
                                        <div style="color: #666; font-size: 12px;">
                                            {claim['category'] if pd.notna(claim['category']) else 'No category'}
                                        </div>
                                    </div>
                                    """, unsafe_allow_html=True)
                                    
                                    # Evidence panel toggle
                                    evidence_key = f"evidence_{facility_id}_{claim_idx}"
                                    if evidence_key not in st.session_state:
                                        st.session_state[evidence_key] = False
                                    
                                    if st.button(
                                        "🔍 View Evidence" if not st.session_state[evidence_key] else "🔼 Hide Evidence",
                                        key=f"btn_{evidence_key}"
                                    ):
                                        st.session_state[evidence_key] = not st.session_state[evidence_key]
                                    
                                    # Show evidence if toggled
                                    if st.session_state[evidence_key]:
                                        if pd.notna(claim['source_text']):
                                            st.caption("**Source Text:**")
                                            st.text_area(
                                                "Evidence",
                                                value=claim['source_text'],
                                                height=100,
                                                key=f"text_{evidence_key}",
                                                label_visibility="collapsed",
                                                disabled=True
                                            )
                                            if not pd.isna(confidence):
                                                st.caption(f"Confidence: {confidence:.2%}")
                                        else:
                                            st.caption("⚠️ No source text available")
                else:
                    st.info("ℹ️ No claims extracted for this facility")
                
                # Review Actions
                st.markdown("### 📝 Review Actions")
                
                # Helper function to save review
                def save_review(facility_id, decision):
                    try:
                        review_id = str(uuid.uuid4())
                        created_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        facility_id_safe = facility_id.replace("'", "''")
                        
                        insert_sql = f"""
                        INSERT INTO virtue_foundation_silver.healthcare_facilities.review_decisions
                        (review_id, facility_id, reviewer, decision, field_reviewed, note, created_at)
                        VALUES (
                            '{review_id}',
                            '{facility_id_safe}',
                            '{st.session_state.reviewer_name}',
                            '{decision}',
                            NULL,
                            NULL,
                            '{created_at}'
                        )
                        """
                        
                        cursor = conn.cursor()
                        cursor.execute(insert_sql)
                        cursor.close()
                        return True
                    except Exception as e:
                        st.error(f"Error saving review: {str(e)}")
                        return False
                
                col_a, col_b, col_c = st.columns(3)
                
                with col_a:
                    if st.button("✅ Verify", key=f"verify_{idx}", use_container_width=True):
                        if save_review(facility_id, "verified"):
                            st.success("✅ Facility verified and saved!")
                            st.info("👉 Check 'My Reviews' tab")
                
                with col_b:
                    if st.button("🚫 Reject", key=f"reject_{idx}", use_container_width=True):
                        if save_review(facility_id, "rejected"):
                            st.error("🚫 Facility rejected and saved!")
                            st.info("👉 Check 'My Reviews' tab")
                
                with col_c:
                    if st.button("ℹ️ Needs Info", key=f"needs_info_{idx}", use_container_width=True):
                        if save_review(facility_id, "needs_more_info"):
                            st.warning("ℹ️ Needs more info - saved!")
                            st.info("👉 Check 'My Reviews' tab")
        
        conn.close()
    
    except Exception as e:
        st.error(f"Error loading review queue: {str(e)}")
        import traceback
        st.code(traceback.format_exc())
