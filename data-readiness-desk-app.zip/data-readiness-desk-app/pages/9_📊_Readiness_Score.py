import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from utils.db_connector import get_connection

st.set_page_config(page_title="Facility Readiness Score", page_icon="📊", layout="wide")

st.title("📊 Facility Readiness Score")
st.markdown("""
This page calculates a **composite Readiness Score (0-100)** for each facility based on:
* **Data Completeness** (40% weight) - How complete the facility data is
* **Coordinate Validity** (20% weight) - Valid lat/lon coordinates
* **Pincode Validity** (20% weight) - Valid postal code
* **Claims Confidence** (20% weight) - Average confidence of extracted claims

**Formula**: `Readiness = 0.4×Completeness + 0.2×CoordValid + 0.2×PincodeValid + 0.2×ClaimsConf`
""")

conn = get_connection()

if not conn:
    st.error("⚠️ **Database Connection Failed**")
    st.info("Please configure the DATABRICKS_TOKEN environment variable.")
    st.stop()

try:
    # Query facilities with all readiness components
    readiness_query = """
    WITH facility_base AS (
        SELECT
            f.facility_id,
            f.name,
            f.address_city,
            f.address_state,
            f.address_pincode,
            f.latitude,
            f.longitude,
            f.data_quality_score as completeness_score,
            -- Coordinate validity: 100 if both lat/lon exist and are in valid ranges, else 0
            CASE 
                WHEN f.latitude IS NOT NULL 
                    AND f.longitude IS NOT NULL
                    AND f.latitude BETWEEN -90 AND 90
                    AND f.longitude BETWEEN -180 AND 180
                THEN 100.0
                ELSE 0.0
            END as coordinate_validity,
            -- Pincode validity: 100 if exists and is 6 digits, else 0
            CASE 
                WHEN f.address_pincode IS NOT NULL 
                    AND LENGTH(CAST(f.address_pincode AS STRING)) = 6
                    AND CAST(f.address_pincode AS STRING) REGEXP '^[0-9]{6}$'
                THEN 100.0
                ELSE 0.0
            END as pincode_validity
        FROM virtue_foundation_silver.healthcare_facilities.facilities_clean f
        WHERE LENGTH(f.facility_id) = 36
            AND f.facility_id LIKE '%-%-%-%-%'
            AND f.name IS NOT NULL
            AND TRIM(f.name) != ''
            AND LENGTH(TRIM(f.name)) > 3
    ),
    
    claims_confidence AS (
        SELECT 
            facility_id,
            AVG(confidence_score) * 100 as avg_claims_confidence,
            COUNT(*) as claim_count
        FROM (
            SELECT facility_id, confidence_score 
            FROM virtue_foundation_silver.healthcare_facilities.facility_capabilities
            WHERE confidence_score IS NOT NULL
            
            UNION ALL
            
            SELECT facility_id, confidence_score 
            FROM virtue_foundation_silver.healthcare_facilities.facility_equipment
            WHERE confidence_score IS NOT NULL
            
            UNION ALL
            
            SELECT facility_id, confidence_score 
            FROM virtue_foundation_silver.healthcare_facilities.facility_procedures
            WHERE confidence_score IS NOT NULL
            
            UNION ALL
            
            SELECT facility_id, confidence_score 
            FROM virtue_foundation_silver.healthcare_facilities.facility_specialties
            WHERE confidence_score IS NOT NULL
        )
        GROUP BY facility_id
    )
    
    SELECT
        fb.facility_id,
        fb.name,
        fb.address_city,
        fb.address_state,
        fb.address_pincode,
        fb.latitude,
        fb.longitude,
        fb.completeness_score,
        fb.coordinate_validity,
        fb.pincode_validity,
        COALESCE(cc.avg_claims_confidence, 0) as claims_confidence,
        COALESCE(cc.claim_count, 0) as claim_count,
        -- Composite Readiness Score (weighted average)
        (
            0.4 * fb.completeness_score +
            0.2 * fb.coordinate_validity +
            0.2 * fb.pincode_validity +
            0.2 * COALESCE(cc.avg_claims_confidence, 0)
        ) as readiness_score
    FROM facility_base fb
    LEFT JOIN claims_confidence cc ON fb.facility_id = cc.facility_id
    ORDER BY readiness_score DESC
    LIMIT 500
    """
    
    df = pd.read_sql(readiness_query, conn)
    conn.close()
    
    if df.empty:
        st.warning("No facilities found")
        st.stop()
    
    # Summary metrics
    st.markdown("---")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        avg_readiness = df['readiness_score'].mean()
        st.metric("Average Readiness", f"{avg_readiness:.1f}")
    
    with col2:
        plan_ready = len(df[df['readiness_score'] >= 80])
        st.metric("Plan-Ready (≥80)", plan_ready, delta=f"{plan_ready/len(df)*100:.1f}%")
    
    with col3:
        needs_work = len(df[df['readiness_score'] < 60])
        st.metric("Needs Work (<60)", needs_work, delta=f"{needs_work/len(df)*100:.1f}%")
    
    with col4:
        st.metric("Total Facilities", len(df))
    
    # Distribution chart
    st.markdown("---")
    st.subheader("📈 Readiness Score Distribution")
    
    fig_dist = px.histogram(
        df, 
        x='readiness_score',
        nbins=20,
        title='Distribution of Facility Readiness Scores',
        labels={'readiness_score': 'Readiness Score', 'count': 'Number of Facilities'},
        color_discrete_sequence=['#1f77b4']
    )
    fig_dist.add_vline(x=80, line_dash="dash", line_color="green", 
                       annotation_text="Plan-Ready Threshold (80)")
    fig_dist.add_vline(x=60, line_dash="dash", line_color="orange",
                       annotation_text="Needs Work Threshold (60)")
    st.plotly_chart(fig_dist, use_container_width=True)
    
    # Filters
    st.markdown("---")
    st.subheader("🔍 Filter Facilities")
    
    col_f1, col_f2, col_f3 = st.columns(3)
    
    with col_f1:
        min_readiness = st.slider("Minimum Readiness Score", 0, 100, 0, 5)
    
    with col_f2:
        state_options = ['All'] + sorted(df['address_state'].dropna().unique().tolist())
        selected_state = st.selectbox("State", state_options)
    
    with col_f3:
        city_options = ['All'] + sorted(df['address_city'].dropna().unique().tolist())
        selected_city = st.selectbox("City", city_options)
    
    # Apply filters
    filtered_df = df[df['readiness_score'] >= min_readiness].copy()
    if selected_state != 'All':
        filtered_df = filtered_df[filtered_df['address_state'] == selected_state]
    if selected_city != 'All':
        filtered_df = filtered_df[filtered_df['address_city'] == selected_city]
    
    st.info(f"📊 Showing {len(filtered_df)} facilities")
    
    # Facility cards with score breakdown
    st.markdown("---")
    st.subheader("🏥 Facility Readiness Details")
    
    for idx, facility in filtered_df.head(50).iterrows():
        with st.container():
            # Score badge color
            score = facility['readiness_score']
            if score >= 80:
                score_color = "🟢"
                badge_bg = "#28a745"
            elif score >= 60:
                score_color = "🟡"
                badge_bg = "#ffc107"
            else:
                score_color = "🔴"
                badge_bg = "#dc3545"
            
            # Header row
            col1, col2, col3 = st.columns([4, 1, 1])
            
            with col1:
                st.markdown(f"### {facility['name']}")
                location_parts = [
                    facility['address_city'],
                    facility['address_state'],
                    facility['address_pincode']
                ]
                location = ", ".join([str(p) for p in location_parts if pd.notna(p)])
                st.caption(f"📍 {location if location else 'Location not specified'}")
            
            with col2:
                st.markdown(f"""
                <div style="text-align: center; padding: 10px; background-color: {badge_bg}; color: white; border-radius: 8px; font-size: 24px; font-weight: bold;">
                    {score_color} {score:.1f}
                </div>
                """, unsafe_allow_html=True)
                st.caption("Readiness Score")
            
            with col3:
                st.metric("Claims", int(facility['claim_count']))
            
            # Score breakdown in expander
            with st.expander("📋 View Score Breakdown", expanded=False):
                # Component scores
                components_col1, components_col2 = st.columns(2)
                
                with components_col1:
                    st.markdown("**Score Components:**")
                    
                    # Completeness
                    comp_score = facility['completeness_score']
                    comp_contrib = 0.4 * comp_score
                    st.markdown(f"""
                    **Data Completeness** (40% weight)  
                    Score: {comp_score:.1f} → Contribution: {comp_contrib:.1f}
                    """)
                    st.progress(comp_score / 100)
                    
                    # Coordinates
                    coord_score = facility['coordinate_validity']
                    coord_contrib = 0.2 * coord_score
                    st.markdown(f"""
                    **Coordinate Validity** (20% weight)  
                    Score: {coord_score:.1f} → Contribution: {coord_contrib:.1f}
                    """)
                    st.progress(coord_score / 100)
                
                with components_col2:
                    st.markdown("**&nbsp;**")  # Spacing
                    
                    # Pincode
                    pin_score = facility['pincode_validity']
                    pin_contrib = 0.2 * pin_score
                    st.markdown(f"""
                    **Pincode Validity** (20% weight)  
                    Score: {pin_score:.1f} → Contribution: {pin_contrib:.1f}
                    """)
                    st.progress(pin_score / 100)
                    
                    # Claims confidence
                    claims_score = facility['claims_confidence']
                    claims_contrib = 0.2 * claims_score
                    st.markdown(f"""
                    **Claims Confidence** (20% weight)  
                    Score: {claims_score:.1f} → Contribution: {claims_contrib:.1f}
                    """)
                    st.progress(claims_score / 100)
                
                # Formula breakdown
                st.markdown("---")
                st.markdown(f"""
                **Formula:**  
                `Readiness = 0.4×{comp_score:.1f} + 0.2×{coord_score:.1f} + 0.2×{pin_score:.1f} + 0.2×{claims_score:.1f}`  
                `Readiness = {comp_contrib:.1f} + {coord_contrib:.1f} + {pin_contrib:.1f} + {claims_contrib:.1f}`  
                `Readiness = {score:.1f}`
                """)
                
                # Issues/recommendations
                st.markdown("---")
                st.markdown("**Recommendations:**")
                issues = []
                
                if comp_score < 80:
                    issues.append("⚠️ Improve data completeness (missing fields)")
                if coord_score < 100:
                    issues.append("📍 Add or validate geographic coordinates")
                if pin_score < 100:
                    issues.append("📮 Verify and correct postal code")
                if claims_score < 60:
                    issues.append("📝 Validate extracted claims (low confidence)")
                
                if issues:
                    for issue in issues:
                        st.markdown(f"* {issue}")
                else:
                    st.success("✅ Facility is plan-ready!")
            
            st.markdown("---")

except Exception as e:
    st.error(f"Error calculating readiness scores: {str(e)}")
    import traceback
    st.code(traceback.format_exc())
