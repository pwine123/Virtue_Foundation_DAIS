import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from utils.db_connector import get_connection
import re

st.set_page_config(page_title="Readiness vs Need", page_icon="📊", layout="wide")

st.title("📊 Readiness vs Need")
st.markdown("""
Identify priority districts by mapping **data readiness** against **health need**.  
Districts in the **high-need / low-readiness quadrant** require immediate attention — poor data quality in areas with the greatest health challenges.
""")

# Helper function to clean numeric values
def clean_numeric(val):
    """Clean messy numeric values from NFHS data"""
    if val is None or (isinstance(val, float) and pd.isna(val)):
        return None
    
    val_str = str(val).strip()
    
    # Remove asterisks, trailing spaces
    val_str = val_str.replace('*', '').strip()
    
    # Extract number from parentheses like "(73.2)"
    paren_match = re.search(r'\(([0-9.]+)\)', val_str)
    if paren_match:
        val_str = paren_match.group(1)
    
    # Try to convert to float
    try:
        return float(val_str)
    except (ValueError, AttributeError):
        return None

# Completeness threshold slider
st.sidebar.header("Settings")
completeness_threshold = st.sidebar.slider(
    "Completeness Score Threshold",
    min_value=0,
    max_value=100,
    value=60,
    step=5,
    help="Used to compute verdicts and % plan-ready facilities"
)

st.sidebar.markdown("""
**Chart Axes:**
* **X-axis (Readiness):** % of district's facilities that are 'Plan-ready'
* **Y-axis (Need):** Composite health need score from NFHS-5 indicators

**Priority Zone:** High need + Low readiness (top-left quadrant)
""")

conn = get_connection()

if not conn:
    st.error("⚠️ **Database Connection Failed**")
    st.info("Please configure the database connection in app settings.")
    st.stop()

try:
    st.header("District Prioritization Map")
    
    # Build combined readiness + need query
    combined_query = f"""
    WITH facility_flags_summary AS (
        SELECT
            facility_id,
            COUNT(CASE WHEN flag_severity = 'high' AND resolved_at IS NULL THEN 1 END) as open_high_flags,
            COUNT(CASE WHEN flag_severity = 'medium' AND resolved_at IS NULL THEN 1 END) as open_medium_flags
        FROM virtue_foundation_silver.healthcare_facilities.data_quality_flags
        GROUP BY facility_id
    ),
    
    claim_quality AS (
        SELECT
            facility_id,
            AVG(confidence_score) as avg_confidence
        FROM (
            SELECT facility_id, confidence_score FROM virtue_foundation_silver.healthcare_facilities.facility_capabilities
            UNION ALL
            SELECT facility_id, confidence_score FROM virtue_foundation_silver.healthcare_facilities.facility_procedures
            UNION ALL
            SELECT facility_id, confidence_score FROM virtue_foundation_silver.healthcare_facilities.facility_equipment
            UNION ALL
            SELECT facility_id, confidence_score FROM virtue_foundation_silver.healthcare_facilities.facility_specialties
        )
        GROUP BY facility_id
    ),
    
    facility_verdicts AS (
        SELECT
            f.facility_id,
            COALESCE(ae.validated_district, 'Unknown') as validated_district,
            CASE
                WHEN LENGTH(f.facility_id) != 36 OR f.facility_id NOT LIKE '%-%-%-%-%' THEN 'Do not trust'
                WHEN COALESCE(flags.open_high_flags, 0) > 0 THEN 'Do not trust'
                WHEN COALESCE(flags.open_medium_flags, 0) > 0 THEN 'Needs review'
                WHEN COALESCE(f.completeness_score, 0.0) < {completeness_threshold} THEN 'Needs review'
                WHEN COALESCE(f.has_valid_coordinates, false) = false THEN 'Needs review'
                WHEN COALESCE(f.has_valid_pincode, false) = false THEN 'Needs review'
                WHEN COALESCE(cq.avg_confidence, 0.0) < 0.5 THEN 'Needs review'
                ELSE 'Plan-ready'
            END as verdict
        FROM virtue_foundation_silver.healthcare_facilities.facilities_clean f
        LEFT JOIN virtue_foundation_silver.healthcare_facilities.facility_address_enriched ae
            ON f.facility_id = ae.facility_id
        LEFT JOIN facility_flags_summary flags
            ON f.facility_id = flags.facility_id
        LEFT JOIN claim_quality cq
            ON f.facility_id = cq.facility_id
        WHERE LENGTH(f.facility_id) = 36
            AND f.facility_id LIKE '%-%-%-%-%'
    ),
    
    district_readiness AS (
        SELECT
            validated_district,
            COUNT(*) as total_facilities,
            SUM(CASE WHEN verdict = 'Plan-ready' THEN 1 ELSE 0 END) as plan_ready_count,
            ROUND(SUM(CASE WHEN verdict = 'Plan-ready' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) as plan_ready_pct
        FROM facility_verdicts
        WHERE validated_district IS NOT NULL
        GROUP BY validated_district
    ),
    
    district_health_need AS (
        SELECT
            district_name,
            state_ut,
            child_u5_who_are_stunted_height_for_age_18_pct as stunted_raw,
            child_u5_who_are_underweight_weight_for_age_18_pct as underweight_raw,
            non_pregnant_w15_49_who_are_anaemic_lt_12_0_g_dl_22_pct as anaemic
        FROM virtue_foundation_silver.healthcare_facilities.facility_district_health_context
        GROUP BY district_name, state_ut, stunted_raw, underweight_raw, anaemic
    )
    
    SELECT
        dr.validated_district,
        dh.state_ut,
        dr.total_facilities,
        dr.plan_ready_count,
        dr.plan_ready_pct,
        dh.stunted_raw,
        dh.underweight_raw,
        dh.anaemic
    FROM district_readiness dr
    INNER JOIN district_health_need dh
        ON UPPER(dr.validated_district) = UPPER(dh.district_name)
    WHERE dr.total_facilities >= 5
    """
    
    df = pd.read_sql(combined_query, conn)
    
    if len(df) > 0:
        # Clean health indicator columns
        df['stunted'] = df['stunted_raw'].apply(clean_numeric)
        df['underweight'] = df['underweight_raw'].apply(clean_numeric)
        
        # anaemic is already numeric (DOUBLE)
        # but composite needs all three
        df = df.dropna(subset=['stunted', 'underweight', 'anaemic'])
        
        # Compute composite health need score (average of three indicators)
        df['health_need_score'] = (df['stunted'] + df['underweight'] + df['anaemic']) / 3
        
        # Summary metrics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Districts", len(df))
        with col2:
            avg_readiness = df['plan_ready_pct'].mean()
            st.metric("Avg Readiness", f"{avg_readiness:.1f}%")
        with col3:
            avg_need = df['health_need_score'].mean()
            st.metric("Avg Health Need", f"{avg_need:.1f}%")
        with col4:
            high_need_low_readiness = ((df['health_need_score'] > avg_need) & (df['plan_ready_pct'] < avg_readiness)).sum()
            st.metric("⚠️ Priority Districts", high_need_low_readiness)
        
        st.divider()
        
        # Create scatter plot
        fig = go.Figure()
        
        # Add quadrant shading (priority zone: high need, low readiness)
        fig.add_shape(
            type="rect",
            x0=0, x1=avg_readiness,
            y0=avg_need, y1=df['health_need_score'].max() * 1.1,
            fillcolor="rgba(255, 0, 0, 0.1)",
            line=dict(width=0),
            layer="below"
        )
        
        # Add median lines
        fig.add_hline(y=avg_need, line_dash="dash", line_color="gray", opacity=0.5)
        fig.add_vline(x=avg_readiness, line_dash="dash", line_color="gray", opacity=0.5)
        
        # Add scatter points
        fig.add_trace(go.Scatter(
            x=df['plan_ready_pct'],
            y=df['health_need_score'],
            mode='markers',
            marker=dict(
                size=df['total_facilities'] * 0.5,  # Size by facility count
                sizemode='diameter',
                sizemin=5,
                color=df['health_need_score'],
                colorscale='RdYlGn_r',  # Red = high need, Green = low need
                showscale=True,
                colorbar=dict(title="Health Need<br>Score (%)")
            ),
            text=df.apply(lambda row: 
                f"<b>{str(row['validated_district']) if pd.notna(row['validated_district']) else 'Unknown'}, " +
                f"{str(row['state_ut']) if pd.notna(row['state_ut']) else 'Unknown'}</b><br>" +
                f"Facilities: {int(row['total_facilities'])}<br>" +
                f"Plan-ready: {row['plan_ready_pct']:.1f}%<br>" +
                f"<br><b>District Health Indicators (NFHS-5):</b><br>" +
                f"Stunted (U5): {row['stunted']:.1f}%<br>" +
                f"Underweight (U5): {row['underweight']:.1f}%<br>" +
                f"Anaemic (W15-49): {row['anaemic']:.1f}%<br>" +
                f"Health Need Score: {row['health_need_score']:.1f}%<br>" +
                f"<br><i>Note: Health indicators are district-level context,<br>not facility-level measurements.</i>",
                axis=1
            ),
            hovertemplate='%{text}<extra></extra>',
            customdata=df[['validated_district', 'state_ut']]
        ))
        
        fig.update_layout(
            title="District Readiness vs Health Need",
            xaxis_title="Data Readiness (% Plan-Ready Facilities)",
            yaxis_title="Health Need Score (% - Higher = Greater Need)",
            height=600,
            hovermode='closest',
            annotations=[
                dict(
                    x=avg_readiness * 0.5,
                    y=df['health_need_score'].max() * 1.05,
                    text="<b>PRIORITY ZONE</b><br>High Need + Low Readiness",
                    showarrow=False,
                    font=dict(size=14, color="darkred"),
                    xanchor="center"
                )
            ]
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        st.markdown("""
        **How to read this chart:**
        * Each point is a district; size = number of facilities
        * **X-axis:** Higher % = more facilities are plan-ready (better data quality)
        * **Y-axis:** Higher % = greater health need (worse health outcomes)
        * **Shaded zone (top-left):** Priority districts with high need and low readiness
        * **NFHS-5 indicators** are district-level context from National Family Health Survey, not measured at individual facilities
        """)
        
        st.divider()
        
        # Priority district list
        st.header("Priority Districts Detail")
        
        priority_df = df[(df['health_need_score'] > avg_need) & (df['plan_ready_pct'] < avg_readiness)].copy()
        priority_df = priority_df.sort_values('health_need_score', ascending=False)
        
        if len(priority_df) > 0:
            st.markdown(f"""
            **{len(priority_df)} districts** fall in the priority zone (high need + low readiness).  
            These districts have the greatest health challenges **and** the poorest data quality — fix these first.
            """)
            
            st.dataframe(
                priority_df[[
                    'validated_district', 'state_ut', 'total_facilities',
                    'plan_ready_pct', 'stunted', 'underweight', 'anaemic', 'health_need_score'
                ]].rename(columns={
                    'validated_district': 'District',
                    'state_ut': 'State',
                    'total_facilities': 'Facilities',
                    'plan_ready_pct': '% Plan-Ready',
                    'stunted': 'Stunted U5 (%)',
                    'underweight': 'Underweight U5 (%)',
                    'anaemic': 'Anaemic W15-49 (%)',
                    'health_need_score': 'Health Need Score'
                }),
                use_container_width=True,
                hide_index=True
            )
            
            # Selected district drill-down
            st.subheader("Drill Down to Facilities")
            selected_district = st.selectbox(
                "Select a priority district to see not-ready facilities",
                priority_df['validated_district'].tolist()
            )
            
            if selected_district:
                # Query facilities in selected district
                facility_query = f"""
                WITH facility_flags_summary AS (
                    SELECT
                        facility_id,
                        COUNT(CASE WHEN flag_severity = 'high' AND resolved_at IS NULL THEN 1 END) as open_high_flags,
                        COUNT(CASE WHEN flag_severity = 'medium' AND resolved_at IS NULL THEN 1 END) as open_medium_flags
                    FROM virtue_foundation_silver.healthcare_facilities.data_quality_flags
                    GROUP BY facility_id
                ),
                
                claim_quality AS (
                    SELECT
                        facility_id,
                        AVG(confidence_score) as avg_confidence
                    FROM (
                        SELECT facility_id, confidence_score FROM virtue_foundation_silver.healthcare_facilities.facility_capabilities
                        UNION ALL
                        SELECT facility_id, confidence_score FROM virtue_foundation_silver.healthcare_facilities.facility_procedures
                        UNION ALL
                        SELECT facility_id, confidence_score FROM virtue_foundation_silver.healthcare_facilities.facility_equipment
                        UNION ALL
                        SELECT facility_id, confidence_score FROM virtue_foundation_silver.healthcare_facilities.facility_specialties
                    )
                    GROUP BY facility_id
                )
                
                SELECT
                    f.facility_id,
                    COALESCE(f.name, 'Unknown') as name,
                    COALESCE(f.address_city, 'Unknown') as address_city,
                    COALESCE(f.completeness_score, 0.0) as completeness_score,
                    COALESCE(f.has_valid_coordinates, false) as has_valid_coordinates,
                    COALESCE(f.has_valid_pincode, false) as has_valid_pincode,
                    COALESCE(flags.open_high_flags, 0) as open_high_flags,
                    COALESCE(flags.open_medium_flags, 0) as open_medium_flags,
                    COALESCE(cq.avg_confidence, 0.0) as avg_confidence,
                    CASE
                        WHEN LENGTH(f.facility_id) != 36 OR f.facility_id NOT LIKE '%-%-%-%-%' THEN 'Do not trust'
                        WHEN COALESCE(flags.open_high_flags, 0) > 0 THEN 'Do not trust'
                        WHEN COALESCE(flags.open_medium_flags, 0) > 0 THEN 'Needs review'
                        WHEN COALESCE(f.completeness_score, 0.0) < {completeness_threshold} THEN 'Needs review'
                        WHEN COALESCE(f.has_valid_coordinates, false) = false THEN 'Needs review'
                        WHEN COALESCE(f.has_valid_pincode, false) = false THEN 'Needs review'
                        WHEN COALESCE(cq.avg_confidence, 0.0) < 0.5 THEN 'Needs review'
                        ELSE 'Plan-ready'
                    END as verdict
                FROM virtue_foundation_silver.healthcare_facilities.facilities_clean f
                INNER JOIN virtue_foundation_silver.healthcare_facilities.facility_address_enriched ae
                    ON f.facility_id = ae.facility_id
                LEFT JOIN facility_flags_summary flags
                    ON f.facility_id = flags.facility_id
                LEFT JOIN claim_quality cq
                    ON f.facility_id = cq.facility_id
                WHERE ae.validated_district = '{selected_district.replace("'", "''")}'
                    AND LENGTH(f.facility_id) = 36
                    AND f.facility_id LIKE '%-%-%-%-%'
                ORDER BY 
                    CASE verdict
                        WHEN 'Do not trust' THEN 1
                        WHEN 'Needs review' THEN 2
                        ELSE 3
                    END,
                    completeness_score ASC
                """
                
                df_facilities = pd.read_sql(facility_query, conn)
                
                if len(df_facilities) > 0:
                    not_ready = df_facilities[df_facilities['verdict'] != 'Plan-ready']
                    st.markdown(f"**{len(not_ready)} of {len(df_facilities)} facilities** in {selected_district} are not plan-ready.")
                    
                    st.dataframe(
                        not_ready[[
                            'name', 'address_city', 'verdict', 'completeness_score',
                            'open_high_flags', 'open_medium_flags', 'avg_confidence'
                        ]].rename(columns={
                            'name': 'Facility Name',
                            'address_city': 'City',
                            'verdict': 'Verdict',
                            'completeness_score': 'Completeness',
                            'open_high_flags': 'High Flags',
                            'open_medium_flags': 'Medium Flags',
                            'avg_confidence': 'Avg Confidence'
                        }),
                        use_container_width=True,
                        hide_index=True
                    )
                else:
                    st.info(f"No facilities found in {selected_district}")
        else:
            st.success("✅ No districts currently fall in the priority zone!")
    else:
        st.warning("No data available. Ensure facilities have associated district health context.")

except Exception as e:
    st.error(f"Error loading data: {str(e)}")
    st.exception(e)
