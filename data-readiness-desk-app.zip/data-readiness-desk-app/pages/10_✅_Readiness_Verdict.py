import streamlit as st
import pandas as pd
from utils.db_connector import get_connection

st.set_page_config(page_title="Readiness Verdict", page_icon="✅", layout="wide")

st.title("✅ Readiness Verdict")
st.markdown("""
Assess facility data readiness using a verdict-based system that goes beyond scores.  
Verdicts combine completeness, flags, validation status, and claim quality to determine trustworthiness.
""")

# Completeness threshold slider
st.sidebar.header("Verdict Settings")
completeness_threshold = st.sidebar.slider(
    "Completeness Score Threshold",
    min_value=0,
    max_value=100,
    value=60,
    step=5,
    help="Facilities below this threshold are marked 'Needs review'"
)

st.sidebar.markdown("""
**Verdict Definitions:**
* 🔴 **Do not trust**: Invalid UUID or open high-severity flags
* 🟡 **Needs review**: Open medium flags, low completeness, validation issues, or low claim quality
* 🟢 **Plan-ready**: No blocking issues, sufficient data quality

**Note:** Absence of flags alone does NOT guarantee 'Plan-ready'. Claim quality matters.
""")

# View selection
view_mode = st.radio(
    "View",
    ["Individual Facilities", "District Summary"],
    horizontal=True
)

conn = get_connection()

if not conn:
    st.error("⚠️ **Database Connection Failed**")
    st.info("Please configure the database connection in app settings.")
    st.stop()

try:
    if view_mode == "Individual Facilities":
        st.header("Facility Readiness Verdicts")
        
        # Main query with verdict logic
        verdict_query = f"""
        WITH facility_flags_summary AS (
            SELECT
                facility_id,
                COUNT(CASE WHEN flag_severity = 'high' AND resolved_at IS NULL THEN 1 END) as open_high_flags,
                COUNT(CASE WHEN flag_severity = 'medium' AND resolved_at IS NULL THEN 1 END) as open_medium_flags,
                COUNT(CASE WHEN flag_severity = 'low' AND resolved_at IS NULL THEN 1 END) as open_low_flags,
                FILTER(
                    COLLECT_LIST(
                        CASE WHEN resolved_at IS NULL THEN 
                            STRUCT(COALESCE(flag_severity, 'unknown') as flag_severity, COALESCE(flag_type, 'unknown') as flag_type, COALESCE(flag_description, 'no description') as flag_description) 
                        END
                    ),
                    x -> x IS NOT NULL
                ) as open_flag_details
            FROM virtue_foundation_silver.healthcare_facilities.data_quality_flags
            GROUP BY facility_id
        ),
        
        claim_quality AS (
            SELECT
                facility_id,
                AVG(confidence_score) as avg_confidence
            FROM (
                SELECT facility_id, confidence_score FROM virtue_foundation_silver.healthcare_facilities.facility_capabilities
                UNION ALL
                SELECT facility_id, confidence_score FROM virtue_foundation_silver.healthcare_facilities.facility_procedures
                UNION ALL
                SELECT facility_id, confidence_score FROM virtue_foundation_silver.healthcare_facilities.facility_equipment
                UNION ALL
                SELECT facility_id, confidence_score FROM virtue_foundation_silver.healthcare_facilities.facility_specialties
            )
            GROUP BY facility_id
        ),
        
        facility_verdicts AS (
            SELECT
                f.facility_id,
                COALESCE(f.name, 'Unknown') as name,
                COALESCE(f.address_city, 'Unknown') as address_city,
                COALESCE(f.address_state, 'Unknown') as address_state,
                COALESCE(ae.validated_district, 'Unknown') as validated_district,
                COALESCE(f.completeness_score, 0.0) as completeness_score,
                COALESCE(f.has_valid_coordinates, false) as has_valid_coordinates,
                COALESCE(f.has_valid_pincode, false) as has_valid_pincode,
                COALESCE(flags.open_high_flags, 0) as open_high_flags,
                COALESCE(flags.open_medium_flags, 0) as open_medium_flags,
                COALESCE(flags.open_low_flags, 0) as open_low_flags,
                COALESCE(flags.open_flag_details, ARRAY()) as open_flag_details,
                COALESCE(cq.avg_confidence, 0.0) as avg_confidence,
                CASE
                    WHEN LENGTH(f.facility_id) != 36 OR f.facility_id NOT LIKE '%-%-%-%-%' THEN 'Do not trust'
                    WHEN COALESCE(flags.open_high_flags, 0) > 0 THEN 'Do not trust'
                    WHEN COALESCE(flags.open_medium_flags, 0) > 0 THEN 'Needs review'
                    WHEN COALESCE(f.completeness_score, 0.0) < {completeness_threshold} THEN 'Needs review'
                    WHEN COALESCE(f.has_valid_coordinates, false) = false THEN 'Needs review'
                    WHEN COALESCE(f.has_valid_pincode, false) = false THEN 'Needs review'
                    WHEN COALESCE(cq.avg_confidence, 0.0) < 0.5 THEN 'Needs review'
                    ELSE 'Plan-ready'
                END as verdict
            FROM virtue_foundation_silver.healthcare_facilities.facilities_clean f
            LEFT JOIN virtue_foundation_silver.healthcare_facilities.facility_address_enriched ae
                ON f.facility_id = ae.facility_id
            LEFT JOIN facility_flags_summary flags
                ON f.facility_id = flags.facility_id
            LEFT JOIN claim_quality cq
                ON f.facility_id = cq.facility_id
            WHERE LENGTH(f.facility_id) = 36
                AND f.facility_id LIKE '%-%-%-%-%'
        )
        
        SELECT *
        FROM facility_verdicts
        ORDER BY 
            CASE verdict
                WHEN 'Do not trust' THEN 1
                WHEN 'Needs review' THEN 2
                ELSE 3
            END,
            completeness_score ASC
        LIMIT 1000
        """
        
        df = pd.read_sql(verdict_query, conn)
        
        if len(df) > 0:
            # Summary metrics
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Total Facilities", len(df))
            with col2:
                do_not_trust = (df['verdict'] == 'Do not trust').sum()
                st.metric("🔴 Do not trust", f"{do_not_trust} ({do_not_trust/len(df)*100:.1f}%)")
            with col3:
                needs_review = (df['verdict'] == 'Needs review').sum()
                st.metric("🟡 Needs review", f"{needs_review} ({needs_review/len(df)*100:.1f}%)")
            with col4:
                plan_ready = (df['verdict'] == 'Plan-ready').sum()
                st.metric("🟢 Plan-ready", f"{plan_ready} ({plan_ready/len(df)*100:.1f}%)")
            
            st.divider()
            
            # Filter by verdict
            verdict_filter = st.multiselect(
                "Filter by verdict",
                ['Do not trust', 'Needs review', 'Plan-ready'],
                default=['Do not trust', 'Needs review']
            )
            
            if verdict_filter:
                df_filtered = df[df['verdict'].isin(verdict_filter)]
            else:
                df_filtered = df
            
            # Display facilities with reasons
            for idx, row in df_filtered.iterrows():
                verdict = row['verdict']
                verdict_icon = {
                    'Do not trust': '🔴',
                    'Needs review': '🟡',
                    'Plan-ready': '🟢'
                }[verdict]
                
                with st.expander(f"{verdict_icon} **{row['name']}** — {verdict}", expanded=(verdict == 'Do not trust')):
                    col1, col2 = st.columns([2, 1])
                    
                    with col1:
                        location_parts = []
                        if pd.notna(row['address_city']):
                            location_parts.append(str(row['address_city']))
                        if pd.notna(row['validated_district']):
                            location_parts.append(str(row['validated_district']))
                        if pd.notna(row['address_state']):
                            location_parts.append(str(row['address_state']))
                        location_str = ", ".join(location_parts) if location_parts else "Location unknown"
                        st.markdown(f"**Location:** {location_str}")
                        st.markdown(f"**Completeness:** {row['completeness_score']:.1f}%")
                        if row['avg_confidence'] is not None:
                            st.markdown(f"**Avg Claim Confidence:** {row['avg_confidence']:.2f}")
                        
                        # Generate plain-language reason
                        if verdict != 'Plan-ready':
                            st.markdown("**Why not plan-ready:**")
                            reasons = []
                            
                            # Check UUID
                            if len(row['facility_id']) != 36 or '-' not in row['facility_id']:
                                reasons.append("• Invalid facility ID format (not a valid UUID)")
                            
                            # Check flags
                            if row['open_high_flags'] > 0:
                                reasons.append(f"• {row['open_high_flags']} open high-severity flag(s)")
                                if row['open_flag_details'] is not None:
                                    for flag in row['open_flag_details']:
                                        if flag and isinstance(flag, dict):
                                            flag_sev = flag.get('flag_severity')
                                            if flag_sev == 'high':
                                                flag_type = str(flag.get('flag_type', 'Unknown'))
                                                flag_desc = str(flag.get('flag_description', 'No description'))
                                                if flag_type and flag_desc:
                                                    reasons.append(f"  - {flag_type}: {flag_desc}")
                            
                            if row['open_medium_flags'] > 0:
                                reasons.append(f"• {row['open_medium_flags']} open medium-severity flag(s)")
                                if row['open_flag_details'] is not None:
                                    for flag in row['open_flag_details']:
                                        if flag and isinstance(flag, dict):
                                            flag_sev = flag.get('flag_severity')
                                            if flag_sev == 'medium':
                                                flag_type = str(flag.get('flag_type', 'Unknown'))
                                                flag_desc = str(flag.get('flag_description', 'No description'))
                                                if flag_type and flag_desc:
                                                    reasons.append(f"  - {flag_type}: {flag_desc}")
                            
                            # Check completeness
                            if row['completeness_score'] < completeness_threshold:
                                reasons.append(f"• Completeness score ({row['completeness_score']:.1f}%) below threshold ({completeness_threshold}%)")
                            
                            # Check validation
                            if not row['has_valid_coordinates']:
                                reasons.append("• Missing or invalid geographic coordinates")
                            
                            if not row['has_valid_pincode']:
                                reasons.append("• Missing or invalid pincode")
                            
                            # Check claim quality
                            if row['avg_confidence'] is not None and row['avg_confidence'] < 0.5:
                                reasons.append(f"• Low average claim confidence ({row['avg_confidence']:.2f}) across capabilities, procedures, equipment, and specialties")
                                reasons.append("  - Even without open flags, low-confidence claims indicate uncertainty")
                            
                            for reason in reasons:
                                st.markdown(reason)
                    
                    with col2:
                        st.markdown(f"**Open Flags:**")
                        st.markdown(f"High: {row['open_high_flags']}")
                        st.markdown(f"Medium: {row['open_medium_flags']}")
                        st.markdown(f"Low: {row['open_low_flags']}")
                        
                        st.markdown(f"**Validation:**")
                        st.markdown(f"Coordinates: {'✓' if row['has_valid_coordinates'] else '✗'}")
                        st.markdown(f"Pincode: {'✓' if row['has_valid_pincode'] else '✗'}")
            
            if len(df_filtered) == 0:
                st.info("No facilities match the selected verdict filter.")
        else:
            st.warning("No facility data found.")
    
    else:  # District Summary
        st.header("District Readiness Summary")
        
        # District roll-up query
        district_query = f"""
        WITH facility_flags_summary AS (
            SELECT
                facility_id,
                COUNT(CASE WHEN flag_severity = 'high' AND resolved_at IS NULL THEN 1 END) as open_high_flags,
                COUNT(CASE WHEN flag_severity = 'medium' AND resolved_at IS NULL THEN 1 END) as open_medium_flags
            FROM virtue_foundation_silver.healthcare_facilities.data_quality_flags
            GROUP BY facility_id
        ),
        
        claim_quality AS (
            SELECT
                facility_id,
                AVG(confidence_score) as avg_confidence
            FROM (
                SELECT facility_id, confidence_score FROM virtue_foundation_silver.healthcare_facilities.facility_capabilities
                UNION ALL
                SELECT facility_id, confidence_score FROM virtue_foundation_silver.healthcare_facilities.facility_procedures
                UNION ALL
                SELECT facility_id, confidence_score FROM virtue_foundation_silver.healthcare_facilities.facility_equipment
                UNION ALL
                SELECT facility_id, confidence_score FROM virtue_foundation_silver.healthcare_facilities.facility_specialties
            )
            GROUP BY facility_id
        ),
        
        facility_verdicts AS (
            SELECT
                f.facility_id,
                COALESCE(f.address_state, 'Unknown') as address_state,
                COALESCE(ae.validated_district, 'Unknown') as validated_district,
                CASE
                    WHEN LENGTH(f.facility_id) != 36 OR f.facility_id NOT LIKE '%-%-%-%-%' THEN 'Do not trust'
                    WHEN COALESCE(flags.open_high_flags, 0) > 0 THEN 'Do not trust'
                    WHEN COALESCE(flags.open_medium_flags, 0) > 0 THEN 'Needs review'
                    WHEN COALESCE(f.completeness_score, 0.0) < {completeness_threshold} THEN 'Needs review'
                    WHEN COALESCE(f.has_valid_coordinates, false) = false THEN 'Needs review'
                    WHEN COALESCE(f.has_valid_pincode, false) = false THEN 'Needs review'
                    WHEN COALESCE(cq.avg_confidence, 0.0) < 0.5 THEN 'Needs review'
                    ELSE 'Plan-ready'
                END as verdict
            FROM virtue_foundation_silver.healthcare_facilities.facilities_clean f
            LEFT JOIN virtue_foundation_silver.healthcare_facilities.facility_address_enriched ae
                ON f.facility_id = ae.facility_id
            LEFT JOIN facility_flags_summary flags
                ON f.facility_id = flags.facility_id
            LEFT JOIN claim_quality cq
                ON f.facility_id = cq.facility_id
            WHERE LENGTH(f.facility_id) = 36
                AND f.facility_id LIKE '%-%-%-%-%'
        )
        
        SELECT
            address_state,
            validated_district,
            COUNT(*) as total_facilities,
            SUM(CASE WHEN verdict = 'Do not trust' THEN 1 ELSE 0 END) as do_not_trust_count,
            SUM(CASE WHEN verdict = 'Needs review' THEN 1 ELSE 0 END) as needs_review_count,
            SUM(CASE WHEN verdict = 'Plan-ready' THEN 1 ELSE 0 END) as plan_ready_count,
            ROUND(SUM(CASE WHEN verdict = 'Do not trust' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) as do_not_trust_pct,
            ROUND(SUM(CASE WHEN verdict = 'Needs review' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) as needs_review_pct,
            ROUND(SUM(CASE WHEN verdict = 'Plan-ready' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) as plan_ready_pct,
            ROUND((SUM(CASE WHEN verdict = 'Do not trust' THEN 1 ELSE 0 END) + 
                   SUM(CASE WHEN verdict = 'Needs review' THEN 1 ELSE 0 END)) * 100.0 / COUNT(*), 1) as not_ready_pct,
            CASE
                WHEN (SUM(CASE WHEN verdict = 'Do not trust' THEN 1 ELSE 0 END) + 
                      SUM(CASE WHEN verdict = 'Needs review' THEN 1 ELSE 0 END)) * 100.0 / COUNT(*) > 30 
                THEN 'Not plan-ready'
                ELSE 'Acceptable'
            END as district_verdict
        FROM facility_verdicts
        WHERE validated_district IS NOT NULL
        GROUP BY address_state, validated_district
        ORDER BY not_ready_pct DESC, total_facilities DESC
        """
        
        df_district = pd.read_sql(district_query, conn)
        
        if len(df_district) > 0:
            # Summary metrics
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Total Districts", len(df_district))
            with col2:
                not_ready_districts = (df_district['district_verdict'] == 'Not plan-ready').sum()
                st.metric("🔴 Not Plan-Ready Districts", f"{not_ready_districts} ({not_ready_districts/len(df_district)*100:.1f}%)")
            with col3:
                acceptable_districts = (df_district['district_verdict'] == 'Acceptable').sum()
                st.metric("🟢 Acceptable Districts", f"{acceptable_districts} ({acceptable_districts/len(df_district)*100:.1f}%)")
            
            st.markdown("""
            **District Verdict Rules:**  
            A district is marked **'Not plan-ready'** if more than 30% of its facilities are not plan-ready (either 'Do not trust' or 'Needs review').
            """)
            
            st.divider()
            
            # Filter by district verdict
            district_verdict_filter = st.multiselect(
                "Filter by district verdict",
                ['Not plan-ready', 'Acceptable'],
                default=['Not plan-ready']
            )
            
            if district_verdict_filter:
                df_district_filtered = df_district[df_district['district_verdict'].isin(district_verdict_filter)]
            else:
                df_district_filtered = df_district
            
            # Display district table
            st.dataframe(
                df_district_filtered[[
                    'address_state', 'validated_district', 'total_facilities',
                    'do_not_trust_count', 'needs_review_count', 'plan_ready_count',
                    'not_ready_pct', 'district_verdict'
                ]].rename(columns={
                    'address_state': 'State',
                    'validated_district': 'District',
                    'total_facilities': 'Total Facilities',
                    'do_not_trust_count': '🔴 Do Not Trust',
                    'needs_review_count': '🟡 Needs Review',
                    'plan_ready_count': '🟢 Plan-Ready',
                    'not_ready_pct': '% Not Ready',
                    'district_verdict': 'District Verdict'
                }),
                use_container_width=True,
                hide_index=True
            )
            
            if len(df_district_filtered) == 0:
                st.info("No districts match the selected filter.")
        else:
            st.warning("No district data found.")

except Exception as e:
    st.error(f"Error loading data: {str(e)}")
    st.exception(e)
