import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from utils.db_connector import get_connection

st.set_page_config(page_title="Quality Dashboard", page_icon="📊", layout="wide")

st.title("📊 Data Quality Dashboard")

# Try to connect to database
conn = get_connection()

if not conn:
    st.warning("⚠️ **Database Not Connected - Showing Sample Data**")
    st.info("""
    To connect to your live database, you need to configure the DATABRICKS_TOKEN environment variable.
    
    For now, you can see how the dashboard works with sample data below.
    """)
    
    # Show sample data instead
    st.markdown("---")
    st.subheader("📊 Sample Quality Metrics")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Avg Quality Score", "78.5/100")
    with col2:
        st.metric("Critical Issues", "12", delta=None, delta_color="inverse")
    with col3:
        st.metric("High Priority", "34", delta=None, delta_color="inverse")
    with col4:
        st.metric("Production Ready", "2,847", delta=None, delta_color="normal")
    
    st.markdown("---")
    
    # Sample charts
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Issues by Type")
        sample_data = pd.DataFrame({
            'flag_type': ['Missing Coordinates', 'Invalid Pincode', 'Missing Contact', 'Invalid Capacity'],
            'count': [45, 32, 28, 15]
        })
        fig = px.bar(sample_data, x='count', y='flag_type', orientation='h',
                     labels={'count': 'Number of Issues', 'flag_type': 'Issue Type'},
                     color='count', color_continuous_scale='Reds')
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.subheader("Issues by Severity")
        sample_severity = pd.DataFrame({
            'flag_severity': ['critical', 'high', 'medium', 'low'],
            'count': [12, 34, 45, 29]
        })
        colors = {'critical': '#FF3621', 'high': '#FFAB00', 'medium': '#00A972', 'low': '#919191'}
        fig = px.pie(sample_severity, values='count', names='flag_severity',
                     color='flag_severity', color_discrete_map=colors)
        st.plotly_chart(fig, use_container_width=True)
    
    st.info("💡 **This is sample data.** Configure DATABRICKS_TOKEN to see your real healthcare facility data.")
    st.stop()

# If connection works, show real data
try:
    # Overall quality score
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        query = """
            SELECT AVG(data_quality_score) as avg_score
            FROM virtue_foundation_silver.healthcare_facilities.facilities_clean
        """
        avg_score = pd.read_sql(query, conn)['avg_score'][0]
        st.metric("Avg Quality Score", f"{avg_score:.1f}/100")

    with col2:
        query = """
            SELECT COUNT(DISTINCT facility_id) as count
            FROM virtue_foundation_silver.healthcare_facilities.data_quality_flags
            WHERE resolved_at IS NULL AND flag_severity = 'critical'
        """
        critical = pd.read_sql(query, conn)['count'][0]
        st.metric("Critical Issues", critical, delta=None, delta_color="inverse")

    with col3:
        query = """
            SELECT COUNT(DISTINCT facility_id) as count
            FROM virtue_foundation_silver.healthcare_facilities.data_quality_flags
            WHERE resolved_at IS NULL AND flag_severity = 'high'
        """
        high = pd.read_sql(query, conn)['count'][0]
        st.metric("High Priority", high, delta=None, delta_color="inverse")

    with col4:
        query = """
            SELECT COUNT(*) as count
            FROM virtue_foundation_silver.healthcare_facilities.facilities_clean
            WHERE data_quality_score >= 80
        """
        ready = pd.read_sql(query, conn)['count'][0]
        st.metric("Production Ready", ready, delta=None, delta_color="normal")

    st.markdown("---")

    # Issue breakdown by type
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Issues by Type")
        query = """
            SELECT flag_type, COUNT(*) as count
            FROM virtue_foundation_silver.healthcare_facilities.data_quality_flags
            WHERE resolved_at IS NULL
            GROUP BY flag_type
            ORDER BY count DESC
        """
        df = pd.read_sql(query, conn)
        fig = px.bar(df, x='count', y='flag_type', orientation='h',
                     labels={'count': 'Number of Issues', 'flag_type': 'Issue Type'},
                     color='count', color_continuous_scale='Reds')
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        st.subheader("Issues by Severity")
        query = """
            SELECT flag_severity, COUNT(*) as count
            FROM virtue_foundation_silver.healthcare_facilities.data_quality_flags
            WHERE resolved_at IS NULL
            GROUP BY flag_severity
        """
        df = pd.read_sql(query, conn)
        colors = {'critical': '#FF3621', 'high': '#FFAB00', 'medium': '#00A972', 'low': '#919191'}
        fig = px.pie(df, values='count', names='flag_severity',
                     color='flag_severity', color_discrete_map=colors)
        st.plotly_chart(fig, use_container_width=True)

    conn.close()

except Exception as e:
    st.error(f"Error loading dashboard data: {str(e)}")
    st.info("Please check your database credentials and table permissions.")
